document.addEventListener("DOMContentLoaded", function () {
    "use strict";

    // === ЦВЕТОВАЯ ПАЛИТРА ===
    function initColorPalette() {
        // Верхние паллетки (в карточках продуктов)
        $('.top-palletes .pallete-color').on('click keydown', function (e) {
            if (e.type === 'click' || e.key === 'Enter' || e.key === ' ') {
                e.preventDefault();
                const $palleteGroup = $(this).closest('.top-palletes');
                $palleteGroup.find('.pallete-color').removeClass('active').attr('aria-selected', 'false');
                $(this).addClass('active').attr('aria-selected', 'true');
            }
        });
    }

    // === ДОБАВЛЕНИЕ В КОРЗИНУ ===
    function initAddToCart() {
        $(document).on('click', '.add-to-cart-btn', function () {
            const product_id = $(this).closest('.product-item').find('a').data('product-id');
            console.log('Добавление товара в корзину:', product_id);
            $.ajax({
                url: '/cart/add',
                method: 'POST',
                data: { product_id: product_id },
                success: function (data) {
                    // alert(data);
                },
                error: function (jqXHR, textStatus, errorThrown) {
                    console.error("AJAX Error:", textStatus, errorThrown);
                }
            });
        });
    }

    // === ИЗБРАННОЕ ===
    function initFavorites() {
        $(document).on('click', '.fav-btn', function () {
            const product_id = $(this).data('product-id');
            console.log('Переключение избранного для товара:', product_id);
            $.ajax({
                url: '/favorites/toggle',
                method: 'POST',
                data: { product_id: product_id },
                success: function (data) {
                    // Обновление внешнего вида кнопки избранного
                    if (data === 'Товар добавлен в избранное') {
                        $(this).addClass('active');
                    } else if (data === 'Товар удален из избранного') {
                        $(this).removeClass('active');
                        if (window.location.pathname === '/favorites') {
                            $(this).closest('.product-item').remove();
                            if ($('.product-item').length == 0) {
                                window.location.href = '/';
                            }
                        }
                    }
                },
                error: function (jqXHR, textStatus, errorThrown) {
                    console.error("AJAX Error:", textStatus, errorThrown);
                }
            });
        });
    }

    // === ФИЛЬТР И СОРТИРОВКА ===
    function initFilterSidebar() {
        const openFilterBtn = document.getElementById("open-filter-btn");
        if (!openFilterBtn) return;

        const closeFilterBtn = document.getElementById("close-filter-btn");
        const filterSidebar = document.querySelector(".filter-sidebar");
        const filterOverlay = document.querySelector(".filter-overlay");
        const viewMoreButtons = document.querySelectorAll(".view-more");
        const filterOptions = document.querySelectorAll(".filter-option, .pallete-color");
        const clearFiltersBtn = document.querySelector(".clear-filters-btn");
        const showResultsBtn = document.querySelector(".show-results-btn");

        // Открытие/закрытие сайдбара
        const openFilterSidebar = () => {
            filterSidebar.classList.add("open");
            filterOverlay.classList.add("active");
            document.body.style.overflow = "hidden";
        };

        const closeFilterSidebar = () => {
            filterSidebar.classList.remove("open");
            filterOverlay.classList.remove("active");
            document.body.style.overflow = "";
        };

        openFilterBtn.addEventListener("click", openFilterSidebar);
        if (closeFilterBtn) closeFilterBtn.addEventListener("click", closeFilterSidebar);
        if (filterOverlay) filterOverlay.addEventListener("click", closeFilterSidebar);

        // Кнопки "Показать больше/меньше"
        if (viewMoreButtons) {
            viewMoreButtons.forEach((button) => {
                button.addEventListener("click", () => {
                    const hiddenOptions = button.previousElementSibling.querySelector(".hidden-options");
                    if (hiddenOptions) {
                        hiddenOptions.classList.toggle("visible");
                        button.textContent = hiddenOptions.classList.contains("visible") ? "Скрыть" : "Показать больше";
                    }
                });
            });
        }

        // Выбор опций фильтра
        if (filterOptions) {
            filterOptions.forEach((option) => {
                option.addEventListener("click", () => {
                    const parentContainer = option.closest(".filter-options");
                    if (!parentContainer) return;
                    
                    const isSingleChoice = parentContainer.dataset.type === "single-choice";

                    if (isSingleChoice) {
                        // Для радио-кнопок (выбор только одного варианта)
                        parentContainer.querySelectorAll(".filter-option, .pallete-color").forEach((el) => {
                            el.classList.remove("active");
                        });
                        option.classList.add("active");
                    } else {
                        // Для чекбоксов (множественный выбор)
                        option.classList.toggle("active");
                    }
                });
            });
        }

        // Кнопка сброса фильтров
        if (clearFiltersBtn) {
            clearFiltersBtn.addEventListener("click", () => {
                document.querySelectorAll(".filter-option.active, .pallete-color.active").forEach((el) => {
                    if (!el.closest(".filter-options") || 
                        el.closest(".filter-options").dataset.type !== "single-choice" || 
                        !el.classList.contains("active")) {
                        el.classList.remove("active");
                    }
                });
            });
        }

        // Кнопка "Показать результаты"
        if (showResultsBtn) {
            showResultsBtn.addEventListener("click", () => {
                // Здесь можно добавить логику для применения фильтров
                closeFilterSidebar();
            });
        }
    }

    // === SWIPER INIT ===
    function initSwipers() {
        if (typeof Swiper === "undefined") {
            console.warn("Swiper not found");
            return;
        }

        // Инициализация слайдера палитры цветов
        document.querySelectorAll(".pallete-slider").forEach((container) => {
            const swiperEl = container.querySelector(".swiper-container-pallete");
            if (swiperEl) {
                new Swiper(swiperEl, {
                    slidesPerView: 'auto',
                    spaceBetween: 10,
                    loop: false,
                    navigation: {
                        nextEl: container.querySelector(".custom-button-next-pallete"),
                        prevEl: container.querySelector(".custom-button-prev-pallete"),
                    },
                    breakpoints: {
                        320: { slidesPerView: 5, spaceBetween: 5 },
                        576: { slidesPerView: 7, spaceBetween: 8 },
                        992: { slidesPerView: 10, spaceBetween: 10 }
                    }
                });
            }
        });
    }

    // === HEART TOGGLE (ИЗБРАННОЕ) ===
    function initHeartToggle() {
        $(document).on('click', '.heart, .bi-heart-fill', function () {
            const $this = $(this);
            const $path = $this.find('path');
            
            if ($path.length > 0) {
                const currentFill = $path.attr('fill');
                $path.attr('fill', currentFill === 'red' ? 'none' : 'red');
            } else {
                $this.toggleClass('active');
            }
            
            // Если кнопка находится в карточке товара, то вызываем функцию добавления/удаления из избранного
            const $productItem = $this.closest('.product-item');
            if ($productItem.length > 0) {
                const productId = $productItem.find('[data-product-id]').data('product-id');
                if (productId) {
                    console.log('Переключение избранного для товара через иконку сердца:', productId);
                    // Здесь можно добавить AJAX-запрос к серверу
                }
            }
        });
    }

    // === ИНТЕРАКТИВНОСТЬ КАРТОЧЕК ТОВАРОВ ===
    function setupProductCards() {
        // Скрываем цветовые опции по умолчанию
        $('.product-item .color-options').hide();

        // Добавляем эффекты при наведении на карточки товаров
        $('.product-item').hover(
            function() {
                $(this).addClass('hover');
                // Показываем цветовые опции при наведении
                $(this).find('.color-options').fadeIn(200);
            },
            function() {
                $(this).removeClass('hover');
                // Скрываем цветовые опции при уходе курсора
                $(this).find('.color-options').fadeOut(200);
            }
        );
    }

    // === ИНИЦИАЛИЗАЦИЯ ===
    initColorPalette();
    initAddToCart();
    initFavorites();
    initFilterSidebar();
    initSwipers();
    initHeartToggle();
    setupProductCards();

    // Добавляем стили для сайдбара фильтров через JavaScript, если они не определены в CSS
    const style = document.createElement('style');
    style.textContent = `
        .filter-overlay {
            position: fixed;
            top: 0;
            left: 0;
            width: 100%;
            height: 100%;
            background-color: rgba(0, 0, 0, 0.5);
            z-index: 998;
            display: none;
        }
        .filter-overlay.active {
            display: block;
        }
        .filter-sidebar {
            position: fixed;
            top: 0;
            right: -400px;
            width: 400px;
            height: 100%;
            background-color: white;
            z-index: 999;
            transition: right 0.3s ease;
            display: flex;
            flex-direction: column;
            max-width: 85%;
        }
        .filter-sidebar.open {
            right: 0;
        }
        .filter-sidebar-body {
            flex: 1;
            overflow-y: auto;
        }
        .hidden-options {
            display: none;
        }
        .hidden-options.visible {
            display: flex;
        }
        .filter-option {
            background-color: #f5f5f5;
            border: 1px solid transparent;
            transition: all 0.2s ease;
        }
        .filter-option.active {
            background-color: #000;
            color: white;
        }
        .pallete-color {
            width: 26px;
            height: 26px;
            border-radius: 50%;
            cursor: pointer;
            position: relative;
        }
        .pallete-color.active::after {
            content: '';
            position: absolute;
            top: -3px;
            left: -3px;
            right: -3px;
            bottom: -3px;
            border: 1px solid #000;
            border-radius: 50%;
        }
        
        /* Цвета палитры */
        .pallete-color-white { background-color: white; border: 1px solid #ccc; }
        .pallete-color-silver { background-color: silver; }
        .pallete-color-black { background-color: black; }
        .pallete-color-brown { background-color: brown; }
        .pallete-color-yellow { background-color: yellow; }
        .pallete-color-orange { background-color: orange; }
        .pallete-color-red { background-color: red; }
        .pallete-color-pink { background-color: pink; }
        .pallete-color-purple { background-color: purple; }
        .pallete-color-sky { background-color: skyblue; }
        .pallete-color-lavender { background-color: lavender; }
        .pallete-color-lime { background-color: lime; }
        .pallete-color-aqua { background-color: aqua; }
        .pallete-color-mint { background-color: #98ff98; }
        .pallete-color-cream { background-color: #fffdd0; }
        .pallete-color-taupe { background-color: #483c32; }
        .pallete-color-platinum { background-color: #e5e4e2; }
        .pallete-color-navy { background-color: navy; }
        .pallete-color-ivory { background-color: ivory; }
        
        /* Стили для промо-блоков */
        .promotional-item {
            background-size: cover;
            background-position: center;
            min-height: 300px;
            padding: 20px;
            color: white;
            display: flex;
            flex-direction: column;
            justify-content: flex-end;
        }
        
        /* Стили для карточек товаров */
        .product-item {
            position: relative;
            transition: all 0.3s ease;
        }
        .product-item .fav-btn {
            position: absolute;
            top: 10px;
            right: 10px;
            z-index: 10;
            cursor: pointer;
            color: #ccc;
        }
        .product-item .fav-btn.active {
            color: red;
        }
        .product-item .add-to-cart-btn {
            cursor: pointer;
            transition: transform 0.2s ease;
        }
        .product-item .add-to-cart-btn:hover {
            transform: scale(1.1);
        }
        .product-item.hover {
            box-shadow: 0 5px 15px rgba(0,0,0,0.1);
        }
        .product-item .color-options {
            display: none; /* Скрываем цветовые опции по умолчанию */
            position: relative;
            z-index: 5;
        }
    `;
    document.head.appendChild(style);
});