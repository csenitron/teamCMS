# order.py
from datetime import datetime
from ..extensions import db
from .base import BaseModel
from .product import Product
class Order(BaseModel):
    __tablename__ = 'orders'

    customer_id = db.Column(db.Integer, db.ForeignKey('customers.id'), nullable=False)
    status = db.Column(db.String(50), nullable=False, default='new')
    total_price = db.Column(db.Numeric(10,2), default=0)
    created_at = db.Column(db.DateTime, default=datetime.utcnow)
    updated_at = db.Column(db.DateTime, default=datetime.utcnow, onupdate=datetime.utcnow)
    referral_id = db.Column(db.Integer, db.ForeignKey('referrals.id'), nullable=True)
    tax_amount = db.Column(db.Numeric(10,2), default=0)
    shipping_cost = db.Column(db.Numeric(10,2), default=0)
    warehouse_id = db.Column(db.Integer, db.ForeignKey('warehouses.id'), nullable=True)

    items = db.relationship('OrderItem', backref='order')

from ..extensions import db
from .base import BaseModel

class OrderItem(BaseModel):
    __tablename__ = 'order_items'

    order_id = db.Column(db.Integer, db.ForeignKey('orders.id'), nullable=False)
    product_id = db.Column(db.Integer, db.ForeignKey('products.id'), nullable=False)
    quantity = db.Column(db.Integer, default=1)
    price = db.Column(db.Numeric(10,2), default=0)

    product = db.relationship('Product')