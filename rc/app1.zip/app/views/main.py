from click import option
from flask import Blueprint, render_template, redirect, jsonify, request, flash, url_for, session

from ..models.productOptions import ProductOption
from ..models.category import *
from ..models.product import *
from ..models.seo_settings import *
from ..models.page import *
from ..models.site_setings import *
from flask_login import LoginManager, login_user, logout_user, login_required, current_user
from ..models.module import *
from ..models.customer import *
from ..models.favorite import *
from ..models.cart import *
import importlib
import uuid
from urllib.parse import urlparse, urljoin

main_bp = Blueprint('main', __name__)

login_manager = LoginManager()
login_manager.login_view = 'main.custom_auth'  # Перенаправление на custom_auth при отсутствии авторизации


@login_manager.user_loader
def load_user(customer_id):
    return Customer.query.get(int(customer_id))


module_classes = {}

# Загружаем все модули динамически
module_path = os.path.join(os.path.dirname(__file__), "modules")
for filename in os.listdir(module_path):
    if filename.endswith(".py") and filename != "__init__.py":
        module_name = f"app.admin.modules.{filename[:-3]}"
        try:
            module = importlib.import_module(module_name)
            print(f"Модуль загружен: {module_name}")

            # Ищем классы внутри модуля
            for attr in dir(module):
                obj = getattr(module, attr)
                if isinstance(obj, type) and hasattr(obj, 'save_instance'):
                    module_classes[attr] = obj
                    print(f"Добавлен класс {attr} в module_classes")

        except ModuleNotFoundError as e:
            print(f"Ошибка при загрузке модуля {module_name}: {e}")

print("Загруженные модули:", module_classes)


@main_bp.route('/')
def index():
    categories = getPcats()
    home_page = getHomePage()
    seo = SEOSettings('page', home_page.id, home_page.meta_title, home_page.meta_description, home_page.meta_keywords)
    site_settings = getSiteSettings()
    layouts = getPageLayout(home_page.id)
    auth = current_user.is_authenticated
    print(auth)
    modules_data = []
    for layout in sorted(layouts, key=lambda x: (x.row_index, x.col_index)):
        if layout.module_instance_id:
            module_instance = ModuleInstance.query.get(layout.module_instance_id)
            if module_instance:
                # Базовые данные модуля
                module_data = {
                    'row_index': layout.row_index,
                    'col_index': layout.col_index,
                    'col_width': layout.col_width,
                    'module_name': module_instance.module.name.lower().replace(" ", "_"),
                    'template': module_instance.selected_template,
                    'settings': module_instance.settings,
                    'content': module_instance.content,
                    'instance': module_instance
                }

                # Динамически определяем класс модуля
                module_class_name = module_instance.module.name  # Например, "SliderModule"
                module_class = module_classes.get(module_class_name)
                if module_class and hasattr(module_class, 'get_instance_data'):
                    # Добавляем специфичные данные модуля
                    module_data.update(module_class.get_instance_data(module_instance))
                else:
                    # Если класса нет, оставляем только базовые данные
                    print(f"Класс для модуля {module_class_name} не найден в module_classes")

                modules_data.append(module_data)

    print("Данные модулей:", modules_data)
    return render_template('index.html', categories=categories, homePage=home_page, seo=seo,
                           site_settings=site_settings, modules=modules_data, auth=auth)


@main_bp.route('/category/<category_slug>')
def category(category_slug):
    if category_slug is None:
        return redirect('/')

    auth = current_user.is_authenticated
    category = getCategoryBySlug(category_slug)
    cat_products = getProductsByCategoryID(category.id)
    categories = getPcats()
    seo = getSEO('category', category.id)
    subCategories = getSybCategoryByID(category.id)
    site_settings = getSiteSettings()

    # Загружаем опции для всех товаров в списке
    product_options = {}
    for product in cat_products:
        options = ProductOption.get_options_by_product_id(product.id)
        product_options[product.id] = options

    return render_template(
        'front/category.html',
        categories=categories,
        category=category,
        cat_products=cat_products,
        seo=seo,
        subCategories=subCategories,
        site_settings=site_settings,
        auth=auth,
        product_options=product_options  # добавили
    )


@main_bp.route('/product/<product_slug>')
def product(product_slug):
    if product_slug is None:
        return redirect('/')

    auth = current_user.is_authenticated
    categories = getPcats()
    product = getProductBySlug(product_slug)
    seo = getSEO('product', product.id)
    site_settings = getSiteSettings()
    options = ProductOption.get_options_by_product_id(product.id)

    # Получаем до 6 других товаров из той же категории
    related_products = Product.query.filter(
        Product.category_id == product.category_id,
        Product.id != product.id  # исключаем текущий товар
    ).order_by(Product.sort_order, Product.id).limit(6).all()

    # Получаем опции для этих товаров
    product_options = {}
    for related in related_products:
        product_options[related.id] = ProductOption.get_options_by_product_id(related.id)

    return render_template(
        'front/product2.html',
        product=product,
        categories=categories,
        seo=seo,
        site_settings=site_settings,
        auth=auth,
        options=options,
        cat_products=related_products,
        product_options=product_options
    )


@main_bp.route('/search', methods=['GET'])
def search_products():
    query = request.args.get('query', '')  # Получаем текст поиска из запроса
    if len(query) > 3:  # Ограничение: минимум 4 символа
        # Ищем товары, где название содержит query (регистронезависимо)
        products = Product.query.filter(Product.name.ilike(f'%{query}%')).limit(10).all()
        # Преобразуем в список словарей
        results = [{'name': p.name, 'slug': p.slug, 'image': p.main_image.filename, 'price': p.price} for p in products]
        print(results)
        return jsonify(results)  # Возвращаем JSON

    return jsonify([])


@main_bp.route('/custom-auth', methods=['GET', 'POST'])
def custom_auth(action=None):
    # Если пользователь уже авторизован, перенаправляем на главную
    if current_user.is_authenticated and isinstance(current_user, Customer):
        return redirect(url_for('main.index'))  # Замените 'main.index' на вашу главную страницу

    if request.method == 'POST':
        action = request.form.get('action')  # Определяем, вход или регистрация

        if action == 'login':
            email = request.form.get('loginEmail')
            password = request.form.get('loginPassword')

            # Проверка входных данных
            if not email or not password:
                flash('Email и пароль обязательны для входа.', 'danger')
                return render_template('auth.html')

            # Поиск клиента
            customer = Customer.query.filter_by(email=email).first()

            if customer and customer.check_password(password):
                login_user(customer)
                flash('Вход выполнен успешно!', 'success')
                return redirect(url_for('main.index'))
            else:
                flash('Неверный email или пароль.', 'danger')

        elif action == 'register':
            name = request.form.get('registerName')
            email = request.form.get('registerEmail')
            password = request.form.get('registerPassword')
            confirm_password = request.form.get('registerConfirmPassword')

            # Проверка входных данных
            if not all([name, email, password, confirm_password]):
                flash('Все поля обязательны для регистрации.', 'danger')
                return render_template('auth.html')

            if password != confirm_password:
                flash('Пароли не совпадают.', 'danger')
                return render_template('auth.html')

            try:
                # Создание клиента через addCustomer
                new_customer = addCustomer(name, email, password)
                login_user(new_customer)
                flash('Регистрация успешна! Добро пожаловать!', 'success')
                return redirect(url_for('main.index'))

            except ValueError as e:
                flash(str(e), 'danger')
            except Exception as e:
                db.session.rollback()
                flash('Ошибка при регистрации. Попробуйте снова.', 'danger')

    return redirect('/')


@main_bp.route('/logout')
@login_required
def logout():
    logout_user()
    flash('Вы вышли из системы.', 'success')
    return redirect('/')


@main_bp.route('/favorites', methods=['GET', 'POST'])
def favorite():
    if request.method == 'POST':
        product_id = request.form.get('product_id')
        if checkFavorite(current_user.id, product_id):
            deleteFavorite(current_user.id, product_id)
            return 'Товар удален из избранного'
        else:
            addFavorite(current_user.id, product_id)
            return 'Товар добавлен в избранные'

    else:
        seo = SEOSettings(
            page_type='favorite',
            page_id=0,
            meta_title='Избранное',
            meta_description='Закладки',
            meta_keywords='',
            slug='favorite'
        )
        categories = getPcats()
        customer_id = current_user.id
        favorites = getFavorites(customer_id)
        site_settings = getSiteSettings()
        return render_template('front/favorite.html', favorites=favorites, seo=seo, site_settings=site_settings,
                               auth=current_user.is_authenticated, categories=categories)


def is_safe_url(target):
    """Проверяет, что URL безопасен для редиректа."""
    ref_url = urlparse(request.host_url)
    test_url = urlparse(urljoin(request.host_url, target))
    return test_url.scheme in ('http', 'https') and ref_url.netloc == test_url.netloc


def get_session_id():
    """Возвращает или создаёт уникальный ID сессии."""
    if 'session_id' not in session:
        session['session_id'] = str(uuid.uuid4())
    return session['session_id']


def merge_session_cart_to_db():
    """Переносит корзину из сессии в базу данных для авторизованного пользователя."""
    if not current_user.is_authenticated or 'cart' not in session:
        return

    cart = session.get('cart', {})
    for product_id, quantity in cart.items():
        product = Product.query.get(product_id)
        if product and product.stock >= quantity:
            cart_item = CartItem.query.filter_by(customer_id=current_user.id, product_id=product_id).first()
            if cart_item:
                cart_item.quantity += quantity
            else:
                cart_item = CartItem(
                    customer_id=current_user.id,
                    product_id=product_id,
                    quantity=quantity
                )
                db.session.add(cart_item)
    db.session.commit()
    session.pop('cart', None)  # Очищаем корзину в сессии


@main_bp.route('/cart/add', methods=['POST'])
def add_to_cart():
    product_id = request.form.get('product_id', type=int)
    quantity = request.form.get('quantity', type=int, default=1)
    print(product_id, quantity)
    if not product_id or quantity < 1:
        flash('Неверный товар или количество.', 'danger')
        return redirect(request.referrer or url_for('main.index'))

    product = Product.query.get(product_id)
    # if not product or product.stock < quantity:
    #     flash('Товар недоступен или недостаточно на складе.', 'danger')
    #     return redirect(request.referrer or url_for('main.index'))

    if current_user.is_authenticated and isinstance(current_user, Customer):
        # Для авторизованных пользователей
        cart_item = CartItem.query.filter_by(customer_id=current_user.id, product_id=product_id).first()
        if cart_item:
            cart_item.quantity += quantity
        else:
            cart_item = CartItem(customer_id=current_user.id, product_id=product_id, quantity=quantity)
            db.session.add(cart_item)
        db.session.commit()
    else:
        # Для неавторизованных пользователей
        cart = session.get('cart', {})
        cart[str(product_id)] = cart.get(str(product_id), 0) + quantity
        session['cart'] = cart
        session.modified = True

    flash('Товар добавлен в корзину!', 'success')
    # return redirect(request.referrer or url_for('main.index'))
    return 'Товар добавлен в корзину'


@main_bp.route('/cart/remove', methods=['POST'])
def remove_from_cart():
    product_id = request.form.get('product_id', type=int)

    if not product_id:
        flash('Неверный товар.', 'danger')
        return redirect(request.referrer or url_for('main.index'))

    if current_user.is_authenticated and isinstance(current_user, Customer):
        cart_item = CartItem.query.filter_by(customer_id=current_user.id, product_id=product_id).first()
        if cart_item:
            db.session.delete(cart_item)
            db.session.commit()
    else:
        cart = session.get('cart', {})
        cart.pop(str(product_id), None)
        session['cart'] = cart
        session.modified = True

    flash('Товар удален из корзины!', 'success')
    return redirect(request.referrer or url_for('main.index'))


@main_bp.route('/cart', methods=['GET'])
def view_cart():
    cart_items = []
    total_price = 0

    if current_user.is_authenticated and isinstance(current_user, Customer):
        cart_items = CartItem.query.filter_by(customer_id=current_user.id).all()
        for item in cart_items:
            total_price += item.product.price * item.quantity
    else:
        cart = session.get('cart', {})
        for product_id, quantity in cart.items():
            product = Product.query.get(int(product_id))
            if product:
                cart_items.append({'product': product, 'quantity': quantity})
                total_price += product.price * quantity

    seo = SEOSettings(
        page_type='favorite',
        page_id=0,
        meta_title='Избранное',
        meta_description='Закладки',
        meta_keywords='',
        slug='favorite'
    )
    categories = getPcats()
    customer_id = current_user.id
    site_settings = getSiteSettings()
    return render_template('front/cart.html', cart_items=cart_items, total_price=total_price, seo=seo,
                           site_settings=site_settings,
                           auth=current_user.is_authenticated, categories=categories)
