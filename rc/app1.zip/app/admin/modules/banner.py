import json

from flask import flash, redirect, url_for
from ...models.module import ModuleInstance
from ...models.modules.banner import BannerModuleInstance, BannerItem
from ...extensions import db


class BannerModule:
    """Логика сохранения экземпляра баннера и его карточек"""

    @staticmethod
    def save_instance(module_id, form_data, instance_id=None):
        # Проверяем module_id
        if not module_id:
            flash("Ошибка: module_id не передан!", "danger")
            return redirect(url_for('admin.modules_list'))

        # Получаем или создаем ModuleInstance
        module_instance = ModuleInstance.query.get(instance_id) if instance_id else None

        if not module_instance:
            module_instance = ModuleInstance(
                module_id=module_id,
                settings=json.dumps({
                    'name': form_data.get("title"),
                    'status': form_data.get("status") == "on"
                }),
                selected_template="default"
            )
            db.session.add(module_instance)
            db.session.flush()
        else:
            ModuleInstance.query.filter_by(id=module_instance.id).update({
                'settings': json.dumps({
                    'name': form_data.get("title"),
                    'status': form_data.get("status") == "on"
                })
            })

        # Получаем или создаем BannerModuleInstance
        banner_instance = BannerModuleInstance.query.filter_by(module_instance_id=module_instance.id).first()

        if not banner_instance:
            banner_instance = BannerModuleInstance(module_instance_id=module_instance.id)
            db.session.add(banner_instance)
        else:
            # Перед обновлением удаляем старые банер-карточки
            BannerItem.query.filter_by(banner_id=banner_instance.id).delete()

        banner_instance.title = form_data.get("title")
        banner_instance.cards_in_row = int(form_data.get("cards_in_row", 3))

        # Фиксируем изменения перед обработкой карточек
        db.session.commit()

        # Собираем данные для каждого банера (формат полей: banners[индекс][имя_поля])
        banners = {}
        for key, value in form_data.items():
            if key.startswith("banners["):
                # Разбираем ключ вида: banners[INDEX][field_name]
                parts = key.split('[')
                banner_index = parts[1].split(']')[0]
                field_name = parts[2].split(']')[0]
                if banner_index not in banners:
                    banners[banner_index] = {}
                banners[banner_index][field_name] = value

        # Создаем объекты BannerItem
        for banner_index, banner_data in banners.items():
            try:
                bg_img_id = int(banner_data.get("background_image_id"))
            except (TypeError, ValueError):
                bg_img_id = 0  # или можно обработать ошибку

            banner_item = BannerItem(
                banner_id=banner_instance.id,
                background_image_id=bg_img_id,
                text=banner_data.get("text"),
                link_text=banner_data.get("link_text"),
                link_url=banner_data.get("link_url")
            )
            db.session.add(banner_item)

        db.session.commit()

        flash("Баннер сохранён!", "success")
        return redirect(url_for('admin.create_or_edit_module_instance',
                                module_id=module_instance.module_id,
                                instance_id=module_instance.id))

    @staticmethod
    def load_instance_data(instance_id):
        """
        Загружает данные для редактирования экземпляра баннера.
        Возвращает словарь с:
         - module_instance,
         - banner (экземпляр BannerModuleInstance),
         - banners (список объектов BannerItem)
        """
        if instance_id:
            module_instance = ModuleInstance.query.get_or_404(instance_id)
            banner_instance = BannerModuleInstance.query.filter_by(module_instance_id=instance_id).first()
            banner_items = BannerItem.query.filter_by(banner_id=banner_instance.id).all() if banner_instance else []
        else:
            module_instance = None
            banner_instance = None
            banner_items = []

        return {
            "module_instance": module_instance,
            "banner": banner_instance,
            "banners": banner_items
        }

    @staticmethod
    def del_instance(module_id, instance_id):
        """
        Удаляет экземпляр баннера и связанные с ним карточки.
        """
        module_instance = ModuleInstance.query.get(instance_id)
        if not module_instance:
            flash("Ошибка: Экземпляр модуля не найден!", "danger")
            return redirect(url_for('admin.modules_list'))

        banner_instance = BannerModuleInstance.query.filter_by(module_instance_id=instance_id).first()
        if banner_instance:
            BannerItem.query.filter_by(banner_id=banner_instance.id).delete()
            db.session.delete(banner_instance)

        db.session.delete(module_instance)
        db.session.commit()

        flash("Экземпляр модуля успешно удалён.", "success")
        return redirect(url_for('admin.modules_list'))

    @staticmethod
    def get_instance_data(module_instance):

        # Проверяем наличие module_instance
        if not module_instance:
            return {
                'settings': {},
                'banner': None,
                'banner_items': []
            }

        # Извлекаем и парсим настройки из module_instance.settings
        settings = json.loads(module_instance.settings) if module_instance.settings else {}

        # Получаем связанный экземпляр BannerModuleInstance
        banner_instance = BannerModuleInstance.query.filter_by(module_instance_id=module_instance.id).first()

        # Получаем список карточек (BannerItem), если banner_instance существует
        banner_items = BannerItem.query.filter_by(banner_id=banner_instance.id).all() if banner_instance else []
        print(banner_items)
        # Формируем и возвращаем структурированные данные
        return {
            'settings': settings,
            'banner': banner_instance,
            'banner_items': banner_items
        }