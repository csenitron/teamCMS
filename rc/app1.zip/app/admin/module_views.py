import json
import os

from flask import request, jsonify, render_template, flash, redirect, url_for
from .forms import ImageUploadForm, DirectoryForm
import importlib
from . import admin_bp
from ..models.module import Module, ModuleInstance

module_classes = {}

# Загружаем все модули динамически
module_path = os.path.join(os.path.dirname(__file__), "modules")
for filename in os.listdir(module_path):
    if filename.endswith(".py") and filename != "__init__.py":
        module_name = f"app.admin.modules.{filename[:-3]}"
        try:
            module = importlib.import_module(module_name)
            print(f"Модуль загружен: {module_name}")

            # Ищем классы внутри модуля
            for attr in dir(module):
                obj = getattr(module, attr)
                if isinstance(obj, type) and hasattr(obj, 'save_instance'):
                    module_classes[attr] = obj
                    print(f"Добавлен класс {attr} в module_classes")

        except ModuleNotFoundError as e:
            print(f"Ошибка при загрузке модуля {module_name}: {e}")

print("Загруженные модули:", module_classes)


@admin_bp.route('/modules', methods=['GET'])
def modules_list():
    """Вывод всех модулей"""

    modules = Module.query.all()
    instances = ModuleInstance.query.all()

    instances_by_module = {}

    for instance in instances:
        # Распарсиваем JSON перед передачей в шаблон
        settings = json.loads(instance.settings) if instance.settings else {}

        if instance.module_id not in instances_by_module:
            instances_by_module[instance.module_id] = []

        instances_by_module[instance.module_id].append({
            'id': instance.id,
            'settings': settings  # Передаем уже распарсенный JSON
        })

    return render_template(
        'admin/modules/all_modules.html',
        modules=modules,
        instances_by_module=instances_by_module
    )




@admin_bp.route('/modules/<int:module_id>/instance/<int:instance_id>', methods=['GET', 'POST'])
@admin_bp.route('/modules/<int:module_id>/create', methods=['GET', 'POST'])
def create_or_edit_module_instance(module_id, instance_id=None):
    """
    Форма для создания или редактирования экземпляра модуля.
    """
    module = Module.query.get_or_404(module_id)

    if request.method == 'POST':
        module_class = module_classes.get(module.name)
        if module_class and hasattr(module_class, 'save_instance'):

            return module_class.save_instance(module_id, request.form, instance_id)

        flash("Ошибка: обработчик сохранения для этого модуля не найден!", "danger")
        return redirect(url_for('admin.modules_list'))

    # Загружаем данные из метода модуля
    module_class = module_classes.get(module.name)
    context = module_class.load_instance_data(instance_id) if module_class and hasattr(module_class,
                                                                                       'load_instance_data') else {}

    # ✅ Добавляем `slider = None`, если его нет в контексте
    if "slider" not in context:
        context["slider"] = None
    img_form = ImageUploadForm()
    dir_form = DirectoryForm()
    return render_template(
        f"admin/modules/{module.creation_template}",
        module=module,
        img_form=img_form,
        dir_form=dir_form,
                 ** context
    )


@admin_bp.route('/modules/<int:module_id>/delete/<int:instance_id>', methods=['GET', 'POST'])
def delete_module_instance(module_id, instance_id):
    """
    Удаляет экземпляр модуля и связанные с ним данные.
    """
    module = Module.query.get_or_404(module_id)

    # Проверяем, есть ли соответствующий класс модуля
    module_class = module_classes.get(module.name)
    if module_class and hasattr(module_class, 'del_instance'):
        module_class.del_instance(module_id, instance_id)
        flash("Экземпляр модуля успешно удалён.", "success")
    else:
        flash("Ошибка: обработчик удаления для этого модуля не найден!", "danger")

    return redirect(url_for('admin.modules_list'))

