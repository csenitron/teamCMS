# app/admin/views.py
import os
import re
import uuid
import unicodedata
from datetime import datetime
from functools import wraps
from unidecode import unidecode
from flask import Blueprint, current_app, flash, request, redirect, url_for, session, render_template, abort, jsonify
from sqlalchemy.dialects.postgresql import array
from sqlalchemy.exc import IntegrityError
from flask_login import current_user, login_required  # Импорт current_user
from ..models.attributeValue import AttributeValue
from ..models.product import Product, product_images
from ..extensions import db
from ..models.category import Category, build_category_list
from ..models.directory import Directory
from ..models.image import Image
from ..models.seo_settings import SEOSettings
from ..models.order import Order  # для главной страницы статистики
from ..models.productAttribute import ProductAttribute
from ..models.attribute import Attribute
from .forms import CategoryForm, DirectoryForm, ImageUploadForm, ImageEditForm, ProductForm, AttributeForm, \
    ExistingOptionForm, SiteSettingsForm
from .decorators import admin_required
from .utils import save_image_file
from .utils import *
from ..models.productOptions import *
from ..models.site_setings import SiteSettings, SocialLink
from ..models.page import Page
from . import admin_bp



def slugify(value):
    value = unicodedata.normalize('NFKD', value)
    value = value.encode('ascii', 'ignore').decode('ascii')  # убрать не-ASCII символы
    value = re.sub(r'[^a-zA-Z0-9]+', '-', value.lower())
    value = value.strip('-')
    return value





@admin_bp.route('/')
@admin_required
def admin_index():
    print("вход")
    last_orders = Order.query.order_by(Order.created_at.desc()).limit(5).all()
    traffic_info = {
        'today_visits': 120,
        'yesterday_visits': 100,
        'this_month_visits': 3000
    }
    с_user_id = current_user.id

    return render_template('admin/index.html', last_orders=last_orders, traffic=traffic_info, datetime=datetime)


# ---------------------------
#     КАТЕГОРИИ
# ---------------------------

@admin_bp.route('/categories', methods=['GET', 'POST'])
@admin_required
def admin_categories():
    """
    Список категорий (с деревом), + массовые действия (POST).
    """
    if request.method == 'POST':
        action = request.form.get('action')
        selected_ids = request.form.getlist('selected_ids', type=int)
        if action == 'delete_selected':
            for cid in selected_ids:
                cat = Category.query.get(cid)
                if cat:
                    SEOSettings.query.filter_by(page_type='category', page_id=cat.id).delete()
                    db.session.delete(cat)
            db.session.commit()
            flash(f"Удалено {len(selected_ids)} категорий.", "success")
        elif action == 'toggle_index_selected':
            for cid in selected_ids:
                cat = Category.query.get(cid)
                if cat:
                    cat.is_indexed = not cat.is_indexed
            db.session.commit()
            flash(f"Флаг 'Индексировать' переключён для {len(selected_ids)} категорий.", "success")

        return redirect(url_for('admin.admin_categories'))

    # GET
    cat_list = build_category_list(parent_id=None, level=0)
    return render_template('admin/categories_list.html', cat_list=cat_list)


@admin_bp.route('/categories/form', defaults={'category_id': None}, methods=['GET', 'POST'])
@admin_bp.route('/categories/form/<int:category_id>', methods=['GET', 'POST'])
@admin_required
def admin_categories_form(category_id):
    if category_id:
        category = Category.query.get_or_404(category_id)
        existing_seo = SEOSettings.query.filter_by(page_type='category', page_id=category.id).first()
    else:
        category = None
        existing_seo = None

    form = CategoryForm(obj=category)
    # Если SEO уже есть, подставим в форму

    # Дополнительные формы (модалки)
    img_form = ImageUploadForm()
    img_edit_form = ImageEditForm()
    dir_form = DirectoryForm()
    dir_edit_form = DirectoryForm()

    if request.method == 'POST':
        if category_id:
            form.process_slug(category_id)
        else:
            form.process_slug()
        # print("DEBUG: form.data =", form.data)
        # print("DEBUG: form.errors =", form.errors)
        if not category:
            category = Category()

        category.name = form.name.data
        category.slug = form.slug.data or slugify(form.name.data)
        category.sort_order = form.sort_order.data
        category.is_indexed = form.is_indexed.data
        category.description = form.description.data
        # Image ID
        if form.image_id.data:
            category.image_id = int(form.image_id.data)
        else:
            category.image_id = None

        if form.parent.data:
            category.parent_id = form.parent.data.id
        else:
            category.parent_id = None

        db.session.add(category)
        db.session.commit()

        # --- Обновляем или создаём запись SEO ---
        seo = existing_seo or SEOSettings(page_type='category', page_id=category.id)
        seo.meta_title = form.meta_title.data
        seo.meta_description = form.meta_description.data
        seo.meta_keywords = form.meta_keywords.data
        seo.slug = category.slug

        db.session.add(seo)
        db.session.commit()

        return redirect(url_for('admin.admin_categories'))
    if existing_seo:
        form.meta_title.data = existing_seo.meta_title
        form.meta_description.data = existing_seo.meta_description
        form.meta_keywords.data = existing_seo.meta_keywords

    return render_template(
        'admin/category_form.html',
        form=form,
        category=category,
        img_form=img_form,
        img_edit_form=img_edit_form,
        dir_form=dir_form,
        dir_edit_form=dir_edit_form
    )


@admin_bp.route('/categories/<int:category_id>/delete', methods=['POST'])
@admin_required
def admin_categories_delete(category_id):
    category = Category.query.get_or_404(category_id)
    SEOSettings.query.filter_by(page_type='category', page_id=category.id).delete()
    db.session.delete(category)
    db.session.commit()
    return redirect(url_for('admin.admin_categories'))


# ---------------------------
#     ДИРЕКТОРИИ / ИЗОБРАЖЕНИЯ
# ---------------------------




@admin_bp.route('/directories/view', defaults={'dir_id': None})
@admin_bp.route('/directories/view/<int:dir_id>')
@admin_required
def admin_directories_view(dir_id):
    """
    Показ списка каталогов и изображений (полная страница или partial).
    """

    if dir_id and dir_id != 0:
        current_dir = Directory.query.get_or_404(dir_id)
        subdirs = Directory.query.filter_by(parent_id=dir_id).all()
        images = Image.query.filter_by(directory_id=dir_id).all()
    else:
        current_dir = None
        subdirs = Directory.query.filter_by(parent_id=None).all()
        images = Image.query.filter(Image.directory_id.is_(None)).all()

    dir_form = DirectoryForm()
    if current_dir:
        dir_form.parent_id.data = str(current_dir.id)
    else:
        dir_form.parent_id.data = ""

    img_form = ImageUploadForm()
    if current_dir:
        img_form.directory_id.data = str(current_dir.id)
    else:
        img_form.directory_id.data = ""

    img_edit_form = ImageEditForm()
    dir_edit_form = DirectoryForm()
    
    # Получаем все каталоги для выпадающих списков
    all_directories = Directory.query.all()

    # Если AJAX-запрос -> вернуть partial (но у вас пока не используется?)
    if request.headers.get('X-Requested-With') == 'XMLHttpRequest':
        return render_template('admin/_directories_partial.html', current_dir=current_dir,
                               subdirs=subdirs,
                               images=images,
                               dir_form=dir_form,
                               img_form=img_form,
                               all_directories=all_directories)
    else:
        return render_template(
            'admin/directory_view.html',
            current_dir=current_dir,
            subdirs=subdirs,
            images=images,
            dir_form=dir_form,
            img_form=img_form,
            img_edit_form=img_edit_form,
            dir_edit_form=dir_edit_form,
            all_directories=all_directories
        )


@admin_bp.route('/directories/create', methods=['POST'])
@admin_required
def admin_directories_create():
    form = DirectoryForm()
    if form.validate_on_submit():
        parent_id = form.parent_id.data
        parent_id = int(parent_id) if parent_id else None
        d = Directory(name=form.name.data, parent_id=parent_id)
        db.session.add(d)
        db.session.commit()
        if request.headers.get('X-Requested-With') == 'XMLHttpRequest':
            # Вернём JSON с полем ok и dir_id
            return jsonify(ok=True, dir_id=parent_id)
        else:
            return redirect(url_for('admin.admin_directories_view', dir_id=parent_id))
    return redirect(request.referrer)


@admin_bp.route('/directories/<int:dir_id>/delete', methods=['POST'])
@admin_required
def admin_directories_delete(dir_id):
    d = Directory.query.get_or_404(dir_id)
    if len(d.images) > 0:
        if request.headers.get('X-Requested-With') == 'XMLHttpRequest':
            return jsonify(ok=False, message="Нельзя удалить каталог, в котором есть изображения"), 400
        return "Нельзя удалить каталог, в котором есть изображения", 400
    parent_id = d.parent_id
    db.session.delete(d)
    db.session.commit()
    
    if request.headers.get('X-Requested-With') == 'XMLHttpRequest':
        return jsonify(ok=True, parent_id=parent_id)
    else:
        return redirect(url_for('admin.admin_directories_view', dir_id=parent_id))


@admin_bp.route('/directories/<int:dir_id>/edit', methods=['GET', 'POST'])
@admin_required
def admin_directories_edit(dir_id):
    """
    Редактирование каталога, если не через модалку, а отдельным шаблоном (может не использоваться).
    """
    d = Directory.query.get_or_404(dir_id)
    form = DirectoryForm(obj=d)
    if request.method == 'GET':
        form.parent_id.data = str(d.parent_id) if d.parent_id else ""
    if form.validate_on_submit():
        d.name = form.name.data
        parent_id = form.parent_id.data
        d.parent_id = int(parent_id) if parent_id else None
        db.session.commit()
        return redirect(url_for('admin.admin_directories_view', dir_id=d.parent_id))
    return "Stub or temporary page", 501


@admin_bp.route('/directories/<int:dir_id>/update', methods=['POST'])
@admin_required
def admin_directories_update(dir_id):
    """
    Обработка переименования каталога (поддержка AJAX).
    """
    d = Directory.query.get_or_404(dir_id)
    
    # Получаем новое имя из запроса
    new_name = request.form.get('name', '').strip()
    
    if not new_name:
        if request.headers.get('X-Requested-With') == 'XMLHttpRequest':
            return jsonify(ok=False, message="Название каталога не может быть пустым"), 400
        return redirect(request.referrer)
    
    # Проверяем уникальность имени в том же родительском каталоге
    existing = Directory.query.filter_by(name=new_name, parent_id=d.parent_id).first()
    if existing and existing.id != d.id:
        if request.headers.get('X-Requested-With') == 'XMLHttpRequest':
            return jsonify(ok=False, message="Каталог с таким именем уже существует"), 400
        return redirect(request.referrer)
    
    d.name = new_name
    db.session.commit()
    
    if request.headers.get('X-Requested-With') == 'XMLHttpRequest':
        return jsonify(ok=True, message="Каталог переименован")
    else:
        return redirect(url_for('admin.admin_directories_view', dir_id=d.parent_id))


@admin_bp.route('/images/upload', methods=['POST'])
@admin_required
def admin_images_upload_post():
    """Обработка загрузки изображений (поддержка множественной загрузки)."""
    
    # Получаем directory_id из формы
    directory_id = request.form.get('directory_id') or None
    if directory_id == 'None' or directory_id == '':
        directory_id = None
    else:
        try:
            directory_id = int(directory_id) if directory_id else None
        except ValueError:
            directory_id = None

    # Получаем загруженные файлы
    uploaded_files = request.files.getlist('image')
    
    if not uploaded_files or not uploaded_files[0].filename:
        return "Ошибка: не выбраны файлы для загрузки", 400

    uploaded_count = 0
    errors = []

    for file in uploaded_files:
        if file and file.filename:
            try:
                original_filename = file.filename
                # Преобразуем русские символы в английские
                sanitized_filename = unidecode(original_filename)
                # Генерируем новое имя файла с сохранением расширения
                filename = save_image_file(file, sanitized_filename)
                
                img = Image(filename=filename, alt='', directory_id=directory_id)
                db.session.add(img)
                uploaded_count += 1
            except Exception as e:
                errors.append(f"Ошибка при загрузке {file.filename}: {str(e)}")

    if uploaded_count > 0:
        db.session.commit()

    if request.headers.get('X-Requested-With') == 'XMLHttpRequest':
        return jsonify(
            ok=True, 
            dir_id=directory_id, 
            uploaded_count=uploaded_count,
            errors=errors
        )
    else:
        return redirect(url_for('admin.admin_directories_view', dir_id=directory_id))


@admin_bp.route('/images/<int:image_id>/update', methods=['POST'])
@admin_required
def admin_images_update(image_id):
    """
    Изменение alt у изображения (поддержка AJAX).
    """
    img = Image.query.get_or_404(image_id)
    
    # Получаем новый alt из запроса
    new_alt = request.form.get('alt', '')
    directory_id = request.form.get('directory_id', img.directory_id)
    
    img.alt = new_alt
    # Пока не меняем directory_id для простоты
    db.session.commit()
    
    if request.headers.get('X-Requested-With') == 'XMLHttpRequest':
        return jsonify(ok=True, message="Изображение обновлено")
    else:
        return redirect(url_for('admin.admin_directories_view', dir_id=img.directory_id))


@admin_bp.route('/images/<int:image_id>/delete', methods=['POST'])
@admin_required
def admin_images_delete(image_id):
    img = Image.query.get_or_404(image_id)
    
    # Удаляем файл с диска
    upload_path = current_app.config['UPLOAD_FOLDER']
    file_path = os.path.join(upload_path, img.filename)
    if os.path.exists(file_path):
        try:
            os.remove(file_path)
        except OSError:
            pass  # Игнорируем ошибки удаления файла
    
    directory_id = img.directory_id
    db.session.delete(img)
    db.session.commit()
    
    if request.headers.get('X-Requested-With') == 'XMLHttpRequest':
        return jsonify(ok=True, directory_id=directory_id)
    else:
        return redirect(url_for('admin.admin_directories_view', dir_id=directory_id))


#                   Товары
@admin_bp.route('/products/form', defaults={'product_id': None}, methods=['GET', 'POST'])
@admin_bp.route('/products/form/<int:product_id>', methods=['GET', 'POST'])
@admin_required
def product_form(product_id):
    import re  # Импортируем re в начале функции
    # 1) Если редактируем
    product = Product.query.get_or_404(product_id) if product_id else None

    # Основная форма
    form = ProductForm(obj=product)
    img_form = ImageUploadForm()
    dir_form = DirectoryForm()

    existing_option_form = ExistingOptionForm()  # выбор уже существующей опции
    product_options = ProductOption.get_options_by_product_id(product_id)
    product_variations = ProductVariation.get_variations_by_product_id(product_id)
    options = db.session.query(ProductOption).all()
    # SEO
    existing_seo = None
    if product:
        existing_seo = SEOSettings.query.filter_by(page_type='product', page_id=product.id).first()

    # -------------------------------
    # [GET] Заполняем форму, если редактируем
    # -------------------------------
    if request.method == 'GET' and product:
        # SEO
        if existing_seo:
            form.meta_title.data = existing_seo.meta_title
            form.meta_description.data = existing_seo.meta_description
            form.meta_keywords.data = existing_seo.meta_keywords

        # Доп. изображения
        if product:
            # Загружаем изображения с порядком
            additional_images_with_order = db.session.query(Image, product_images.c.order) \
                .join(product_images, Image.id == product_images.c.image_id) \
                .filter(product_images.c.product_id == product.id) \
                .order_by(product_images.c.order) \
                .all()

            # Извлекаем только объекты Image и добавляем динамический order
            product.additional_images = []
            for img, order in additional_images_with_order:
                img.order = order  # Добавляем order как динамический атрибут
                product.additional_images.append(img)  # Добавляем в список

            # Заполняем скрытое поле формы с ID изображений (учитывая порядок)
            form.additional_image_ids.data = ",".join(str(img.id) for img in product.additional_images)

            # Проверяем порядок в консоли
            print("IDs изображений:", form.additional_image_ids.data)
        else:
            form.additional_image_ids.data = ""

    # -------------------------------
    # [POST] Сохранение
    # -------------------------------
    if form.validate_on_submit():
        # Создаём товар, если его не было
        if not product:
            product = Product()
            db.session.add(product)

        # Заполняем поля товара
        form.populate_obj(product)
        product.process_slug()

        # Главное изображение
        if form.main_image_id.data:
            product.main_image_id = int(form.main_image_id.data)
        else:
            product.main_image_id = None

        # Доп. изображения
        if form.additional_image_ids.data:
            print("Полученные данные о порядке изображений:",
                  form.additional_image_ids.data)  # Проверяем, что передается в Flask
            ids_list = [int(x) for x in form.additional_image_ids.data.split(',') if x.strip().isdigit()]

            # Удаляем старые связи
            db.session.execute(
                product_images.delete().where(product_images.c.product_id == product.id)
            )

            # Добавляем изображения с новым порядком
            for index, image_id in enumerate(ids_list):
                db.session.execute(
                    product_images.insert().values(
                        product_id=product.id,
                        image_id=image_id,
                        order=index
                    )
                )
                print(f"Добавляем изображение {image_id} с порядком {index}")  # Проверяем, какие данные идут в БД
        else:
            db.session.execute(
                product_images.delete().where(product_images.c.product_id == product.id)
            )

        db.session.commit()

        # ---------- Атрибуты ----------
        if product_id:
            db.session.query(ProductAttribute).filter_by(product_id=product.id).delete()

        raw_attrs = {}
        for key, val in request.form.items():
            if key.startswith('attributes['):
                m = re.match(r'attributes\[(\d+)\]\[(\w+)\]', key)
                if m:
                    idx = int(m.group(1))
                    field = m.group(2)
                    if idx not in raw_attrs:
                        raw_attrs[idx] = {}
                    raw_attrs[idx][field] = val

        for idx, dataA in raw_attrs.items():
            a_name = dataA.get('name')
            a_val = dataA.get('value')
            if a_name and a_val:
                # Создаём или ищем Attribute
                attribute = Attribute.query.filter_by(name=a_name).first()
                if not attribute:
                    attribute = Attribute(name=a_name)
                    db.session.add(attribute)
                    db.session.flush()

                # Создаём/ищем AttributeValue
                attr_value = AttributeValue.query.filter_by(attribute_id=attribute.id, value=a_val).first()
                if not attr_value:
                    attr_value = AttributeValue(attribute_id=attribute.id, value=a_val)
                    db.session.add(attr_value)
                    db.session.flush()

                # Привязка к товару
                pa = ProductAttribute(product_id=product.id, attribute_value_id=attr_value.id)
                db.session.add(pa)

        db.session.execute(
            product_option_association.delete().where(
                product_option_association.c.product_id == product.id
            )
        )
        db.session.execute(
            product_option_value_association.delete().where(
                product_option_value_association.c.product_id == product.id
            )
        )

        raw_options = {}  # Словарь вида { idx: {"name": ..., "values_ids": "..."}, ... }
        for key, val in request.form.items():
            # Ищем шаблон "options[<номер>][existing_option_id]" или "options[<номер>][values_ids]"
            match_opt = re.match(r'^options\[(\d+)\]\[(\w+)\]$', key)
            if match_opt:
                opt_idx = int(match_opt.group(1))
                field_name = match_opt.group(2)

                if opt_idx not in raw_options:
                    raw_options[opt_idx] = {}
                raw_options[opt_idx][field_name] = val

        for _, opt_data in raw_options.items():
            option_name = opt_data.get('existing_option_id', '').strip()
            values_str = opt_data.get('values_ids', '').strip()
            display_type = opt_data.get('display_type', 'select').strip()
            has_individual_photos = opt_data.get('has_individual_photos', 'false').strip() == 'true'
            
            if not option_name:
                continue

            option = ProductOption.query.filter_by(name=option_name).first()
            if not option:
                option = ProductOption(
                    name=option_name,
                    display_type=display_type,
                    has_individual_photos=has_individual_photos
                )
                db.session.add(option)
                db.session.flush()
            else:
                # Обновляем существующую опцию
                option.display_type = display_type
                option.has_individual_photos = has_individual_photos

            # Связываем товар с этой опцией (product_option_association)
            # Можно просто выполнить INSERT в association-таблицу:
            db.session.execute(
                product_option_association.insert().values(
                    product_id=product.id,
                    option_id=option.id
                )
            )

            # Теперь значения опции (например, "Красный,Белый")
            if values_str:
                for val_name in values_str.split(','):
                    val_name = val_name.strip()
                    if not val_name:
                        continue

                    # Ищем/создаём значение опции
                    value_obj = ProductOptionValue.query.filter_by(
                        option_id=option.id, value=val_name
                    ).first()
                    if not value_obj:
                        value_obj = ProductOptionValue(
                            option_id=option.id,
                            value=val_name
                        )
                        db.session.add(value_obj)
                        db.session.flush()

                    # Связываем товар с этим значением (product_option_value_association)
                    db.session.execute(
                        product_option_value_association.insert().values(
                            product_id=product.id,
                            option_value_id=value_obj.id
                        )
                    )
        db.session.query(ProductVariationOptionValue).filter(
            ProductVariationOptionValue.variation_id.in_(
                db.session.query(ProductVariation.id).filter_by(product_id=product.id)
            )
        ).delete(synchronize_session=False)

        db.session.query(ProductVariation).filter_by(product_id=product.id).delete()

        raw_variations = {}  # { var_idx: { 'sku': ..., 'price': ..., 'combo': {combo_idx: {'name':..., 'value':...}} }, ... }
        for key, val in request.form.items():
            m = re.match(r'^variations\[(\d+)\]\[(\w+)\]$', key)  # основные поля вариации
            if m:
                var_idx = int(m.group(1))
                field = m.group(2)
                if var_idx not in raw_variations:
                    raw_variations[var_idx] = {"combo": {}}
                raw_variations[var_idx][field] = val

            # combo: variations[x][combo][y][name], variations[x][combo][y][value]
            c = re.match(r'^variations\[(\d+)\]\[combo\]\[(\d+)\]\[(\w+)\]$', key)
            if c:

                var_idx = int(c.group(1))
                combo_idx = int(c.group(2))
                combo_field = c.group(3)
                if var_idx not in raw_variations:
                    raw_variations[var_idx] = {"combo": {}}
                if "combo" not in raw_variations[var_idx]:
                    raw_variations[var_idx]["combo"] = {}
                if combo_idx not in raw_variations[var_idx]["combo"]:
                    raw_variations[var_idx]["combo"][combo_idx] = {}

                raw_variations[var_idx]["combo"][combo_idx][combo_field] = val

        # Теперь создаём/сохраняем вариации
        for _, data_v in raw_variations.items():
            sku = data_v.get('sku', '').strip()
            price = data_v.get('price', '0').strip()
            stock = data_v.get('stock', '0').strip()
            slug = data_v.get('slug', '').strip()
            is_photo_variation = data_v.get('is_photo_variation', 'false').strip() == 'true'

            # SEO
            seo_title = data_v.get('seo_title', '').strip()
            seo_desc = data_v.get('seo_description', '').strip()
            seo_keys = data_v.get('seo_keywords', '').strip()
            image_id = data_v.get('image_id')
            image_id = int(image_id) if image_id and image_id.isdigit() else None

            # Проверяем уникальность SKU и генерируем новый если нужно
            if not sku or ProductVariation.query.filter_by(sku=sku).filter(ProductVariation.product_id != product.id).first():
                import time
                if is_photo_variation:
                    sku = f"photo-var-{product.id}-{int(time.time())}"
                else:
                    sku = f"var-{product.id}-{int(time.time())}"

            variation = ProductVariation(
                product_id=product.id,
                sku=sku,
                price=price,
                stock=stock,
                slug=slug or None,
                seo_keys=seo_keys,
                seo_title=seo_title or None,
                seo_description=seo_desc or None,
                image_id=image_id
            )
            variation.generate_slug()
            db.session.add(variation)
            db.session.flush()

            # Обрабатываем combo
            #  Например: data_v["combo"] = {0: {'name': 'Цвет', 'value': 'Красный'}, 1: ...}
            combo_dict = data_v.get('combo', {})

            for _, combo_item in combo_dict.items():
                combo_name = combo_item.get('name', '').strip()
                combo_value = combo_item.get('value', '').strip()
                if not combo_name or not combo_value:
                    continue

                # Ищем нужный option
                option = ProductOption.query.filter_by(name=combo_name).first()
                if not option:
                    # Если вдруг в combo пришла опция, которую ранее не создали — создаём
                    option = ProductOption(name=combo_name, display_type='select')
                    db.session.add(option)
                    db.session.flush()

                # Ищем нужный option_value
                option_value = ProductOptionValue.query.filter_by(
                    option_id=option.id,
                    value=combo_value
                ).first()
                if not option_value:
                    option_value = ProductOptionValue(
                        option_id=option.id,
                        value=combo_value
                    )
                    db.session.add(option_value)
                    db.session.flush()

                # Связь Variation – OptionValue
                pov = ProductVariationOptionValue(
                    variation_id=variation.id,
                    option_value_id=option_value.id
                )
                db.session.add(pov)
        # ---------- SEO ----------
        seo = existing_seo or SEOSettings(page_type='product', page_id=product.id)
        seo.meta_title = form.meta_title.data
        seo.meta_description = form.meta_description.data
        seo.meta_keywords = form.meta_keywords.data
        seo.slug = product.slug
        db.session.add(seo)

        # ---------- Фотографии значений опций ----------
        from ..models.productOptions import ProductOptionValueImage
        
        # Сначала удаляем старые фотографии опций для этого товара
        if product_id:
            # Получаем все значения опций для данного товара
            option_values = db.session.query(ProductOptionValue).join(
                product_option_value_association,
                (product_option_value_association.c.option_value_id == ProductOptionValue.id)
            ).filter(
                product_option_value_association.c.product_id == product.id
            ).all()
            
            for option_value in option_values:
                ProductOptionValueImage.query.filter_by(option_value_id=option_value.id).delete()

        # Обрабатываем новые фотографии опций
        option_photos = {}
        for key, val in request.form.items():
            if key.startswith('option_photos['):
                # Парсим option_photos[OptionName][Value] = "id1,id2,id3"
                match = re.match(r'option_photos\[([^\]]+)\]\[([^\]]+)\]', key)
                if match:
                    option_name = match.group(1)
                    option_value = match.group(2)
                    image_ids = [x.strip() for x in val.split(',') if x.strip()]
                    
                    if option_name not in option_photos:
                        option_photos[option_name] = {}
                    option_photos[option_name][option_value] = image_ids

        # Сохраняем фотографии опций
        for option_name, values_dict in option_photos.items():
            for option_value, image_ids in values_dict.items():
                # Находим ProductOptionValue
                option = ProductOption.query.filter_by(name=option_name).first()
                if option:
                    option_value_obj = ProductOptionValue.query.filter_by(
                        option_id=option.id, value=option_value
                    ).first()
                    
                    if option_value_obj:
                        # Сохраняем каждое изображение
                        for order, image_id in enumerate(image_ids):
                            if image_id.isdigit():
                                photo = ProductOptionValueImage(
                                    option_value_id=option_value_obj.id,
                                    image_id=int(image_id),
                                    order=order,
                                    is_main=(order == 0)  # Первое фото - главное
                                )
                                db.session.add(photo)

        # Сохраняем
        try:
            db.session.commit()
            flash("Товар успешно сохранён.", "success")
        except IntegrityError as e:
            db.session.rollback()
            flash(f"Ошибка БД: {e}", "danger")
            return redirect(url_for('admin.product_form', product_id=product.id))
        except Exception as e:
            db.session.rollback()
            flash(f"Ошибка сохранения: {e}", "danger")
            return redirect(url_for('admin.product_form', product_id=product.id))

        return redirect(url_for('admin.list_products'))

    # GET или не прошла валидацию
    # Подготавливаем данные о фотографиях опций для JavaScript
    import json
    existing_option_photos = {}
    for option in product_options:
        if option.get('has_individual_photos', False):
            option_photos = {}
            for value in option['values']:
                option_photos[value['value']] = value.get('photos', [])
            existing_option_photos[option['name']] = option_photos
    
    print(f"DEBUG: existing_option_photos = {existing_option_photos}")
    existing_option_photos_json = json.dumps(existing_option_photos)
    print(f"DEBUG: existing_option_photos_json = {existing_option_photos_json}")
    
    return render_template(
        'admin/product_form.html',
        form=form,
        product=product,
        options=options,
        product_options=product_options,
        product_variations=product_variations,
        existing_option_form=existing_option_form,
        img_form=img_form,
        dir_form=dir_form,
        existing_option_photos_json=existing_option_photos_json
    )


@admin_bp.route('/products', methods=['GET'])
@admin_required
def list_products():
    query = Product.query

    # Поиск по названию
    search = request.args.get('search', '').strip()
    if search:
        query = query.filter(Product.name.ilike(f"%{search}%"))

    # Фильтр по категории
    category_id = request.args.get('category', type=int)
    if category_id:
        query = query.filter(Product.category_id == category_id)

    # Сортировка
    sort = request.args.get('sort', 'name')
    if sort == 'name':
        query = query.order_by(Product.name.asc())
    elif sort == 'price':
        query = query.order_by(Product.price.asc())
    elif sort == 'stock':
        query = query.order_by(Product.stock.asc())

    # Пагинация
    page = request.args.get('page', 1, type=int)
    per_page = 10
    products = query.paginate(page=page, per_page=per_page)

    # Список категорий для фильтрации
    categories = Category.query.order_by(Category.name.asc()).all()

    return render_template(
        'admin/products_list.html',
        products=products,
        categories=categories,
        search=search,
        category_id=category_id,
        sort=sort
    )


@admin_bp.route('/products/delete/<int:product_id>', methods=['POST'])
@admin_required
def delete_product(product_id):
    product = Product.query.get_or_404(product_id)
    db.session.delete(product)
    db.session.commit()
    flash("Товар удалён", "success")
    return redirect(url_for('admin.list_products'))


@admin_bp.route('/get_option_values', methods=['POST'])
@admin_required
def get_option_values():
    option_id = request.form.get('option_id')
    print("Selected Option ID:", option_id)

    if not option_id:
        return jsonify([]), 400  # Если option_id не передан, возвращаем пустой список с кодом ошибки

    try:
        option_id = int(option_id)  # Преобразуем option_id к типу int
    except ValueError:
        return jsonify([]), 400  # Если option_id не является числом, возвращаем пустой список с кодом ошибки

    option_values = ProductOptionValue.query.filter_by(option_id=option_id).all()
    values = [{'id': value.id, 'value': value.value} for value in option_values]
    return jsonify(values)


@admin_bp.route('/site-settings', methods=['GET', 'POST'])
@admin_required
def site_settings():
    settings = SiteSettings.query.first()
    if not settings:
        settings = SiteSettings()  # еще не добавляем в db.session — только в POST

    pages = Page.query.all()
    form = SiteSettingsForm()

    img_form = ImageUploadForm()
    dir_form = DirectoryForm()

    if request.method == 'GET':
        form.title.data = settings.title
        form.address.data = settings.address
        form.email.data = settings.email
        form.phone.data = settings.phone
        form.owner.data = settings.owner
        form.working_hours.data = settings.working_hours
        form.additional_info.data = settings.additional_info
        form.map_locations.data = settings.map_locations

        if settings.home_page_id:
            form.home_page_id.data = Page.query.filter_by(id=settings.home_page_id).first()

        if settings.logo_id:
            form.image_id.data = str(settings.logo_id)
        else:
            form.image_id.data = ''

        while len(form.social_links.entries) > 0:
            form.social_links.pop_entry()

        existing_links = SocialLink.query.filter_by(site_settings_id=settings.id).all() if settings.id else []
        for link_obj in existing_links:
            entry = form.social_links.append_entry()
            entry.platform.data = link_obj.platform
            entry.url.data = link_obj.url
            if link_obj.icon_id:
                entry.icon_id.data = str(link_obj.icon_id)
                entry.icon.data = link_obj.icon.filename
            else:
                entry.icon_id.data = ''

    if request.method == 'POST':
        settings.title = form.title.data
        settings.address = form.address.data
        settings.email = form.email.data
        settings.phone = form.phone.data
        settings.owner = form.owner.data
        settings.working_hours = form.working_hours.data
        settings.additional_info = form.additional_info.data
        settings.map_locations = form.map_locations.data

        home_pid = form.home_page_id.data
        settings.home_page_id = int(home_pid.id) if home_pid else None

        logo_id_str = form.image_id.data
        if logo_id_str and logo_id_str.isdigit():
            settings.logo_id = int(logo_id_str)
        else:
            settings.logo_id = None

        if not settings.id:
            db.session.add(settings)
            db.session.flush()

        SocialLink.query.filter_by(site_settings_id=settings.id).delete()
        print(form.data)
        for subform in form.social_links.entries:
            if not subform.platform.data and not subform.url.data:
                continue
            new_link = SocialLink(
                site_settings_id=settings.id,
                platform=subform.platform.data,
                url=subform.url.data
            )

            if subform.icon_id.data and subform.icon_id.data.isdigit():
                new_link.icon_id = int(subform.icon_id.data)
            db.session.add(new_link)

        db.session.commit()

        flash("Настройки сайта сохранены!", "success")
        return redirect(url_for('admin.site_settings'))

    return render_template(
        'admin/site_settings.html',
        form=form,
        settings=settings,
        pages=pages,
        img_form=img_form,
        dir_form=dir_form
    )

