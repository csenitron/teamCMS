from ..extensions import db
from .base import BaseModel
from datetime import datetime

class CartItem(BaseModel):
    id = db.Column(db.Integer, primary_key=True)
    customer_id = db.Column(db.Integer, db.ForeignKey('customers.id'), nullable=True)  # Для авторизованных, null для гостей
    session_id = db.Column(db.String(100), nullable=True)  # Для неавторизованных
    product_id = db.Column(db.Integer, db.ForeignKey('products.id'), nullable=False)
    quantity = db.Column(db.Integer, nullable=False, default=1)
    created_at = db.Column(db.DateTime, nullable=False, default=datetime.utcnow)

    product = db.relationship('Product', backref='cart_items')  # Связь с товаром

    def __repr__(self):
        return f'<CartItem product_id={self.product_id} quantity={self.quantity}>'