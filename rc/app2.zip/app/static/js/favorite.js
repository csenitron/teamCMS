$(document).on('click', '.fav-btn', function () {
    let product_id = $(this).attr('data-product-id')
    let product_card =$(this)
    $.ajax({
        url: '/favorites',  // Обратите внимание на добавленный префикс /admin
        method: 'POST',
        data: {product_id: product_id},
        success: function (data) {
            alert(data)

            if (data === 'Товар удален из избранного' && window.location.pathname === '/favorites') {
                console.log(window.location.pathname)
                product_card.closest('.product-item').remove();
                if($('.product-item').length==0){
                    window.location.href='/'
                }
            }

        },
        error: function (jqXHR, textStatus, errorThrown) {
            console.error("AJAX Error:", textStatus, errorThrown);
        }
    });
})