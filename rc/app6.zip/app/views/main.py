from click import option
from flask import Blueprint, render_template, redirect, jsonify, request, flash, url_for, session
from ..extensions import csrf
import json
from decimal import Decimal

from ..models.productOptions import ProductOption, ProductVariation, ProductOptionValue, ProductVariationOptionValue
from ..models.category import *
from ..models.product import *
from ..models.seo_settings import *
from ..models.page import *
from ..models.site_setings import *
from flask_login import LoginManager, login_user, logout_user, login_required, current_user
from ..models.module import *
from ..models.customer import *
from ..models.favorite import *
from ..models.cart import *
import importlib
import uuid
from urllib.parse import urlparse, urljoin

main_bp = Blueprint('main', __name__)

login_manager = LoginManager()
login_manager.login_view = 'main.custom_auth'  # Перенаправление на custom_auth при отсутствии авторизации


def get_all_subcategories(category_id):
    """Получить все подкатегории категории (включая саму категорию)"""
    subcategories = [category_id]
    children = Category.query.filter(Category.parent_id == category_id).all()
    for child in children:
        subcategories.extend(get_all_subcategories(child.id))
    return subcategories


@login_manager.user_loader
def load_user(customer_id):
    return Customer.query.get(int(customer_id))


module_classes = {}

# Загружаем все модули динамически
module_path = os.path.join(os.path.dirname(__file__), "modules")
for filename in os.listdir(module_path):
    if filename.endswith(".py") and filename != "__init__.py":
        module_name = f"app.admin.modules.{filename[:-3]}"
        try:
            module = importlib.import_module(module_name)
            print(f"Модуль загружен: {module_name}")

            # Ищем классы внутри модуля
            for attr in dir(module):
                obj = getattr(module, attr)
                if isinstance(obj, type) and hasattr(obj, 'save_instance'):
                    module_classes[attr] = obj
                    print(f"Добавлен класс {attr} в module_classes")

        except ModuleNotFoundError as e:
            print(f"Ошибка при загрузке модуля {module_name}: {e}")

print("Загруженные модули:", module_classes)


@main_bp.route('/')
def index():
    categories = getPcats()
    home_page = getHomePage()
    seo = SEOSettings('page', home_page.id, home_page.meta_title, home_page.meta_description, home_page.meta_keywords)
    site_settings = getSiteSettings()
    layouts = getPageLayout(home_page.id)
    auth = current_user.is_authenticated
    print(auth)
    modules_data = []
    for layout in sorted(layouts, key=lambda x: (x.row_index, x.col_index)):
        if layout.module_instance_id:
            module_instance = ModuleInstance.query.get(layout.module_instance_id)
            if module_instance:
                # Базовые данные модуля
                module_data = {
                    'row_index': layout.row_index,
                    'col_index': layout.col_index,
                    'col_width': layout.col_width,
                    'module_name': module_instance.module.name.lower().replace(" ", "_"),
                    'template': module_instance.selected_template,
                    'settings': module_instance.settings,
                    'content': module_instance.content,
                    'instance': module_instance
                }

                # Динамически определяем класс модуля
                module_class_name = module_instance.module.name  # Например, "SliderModule"
                module_class = module_classes.get(module_class_name)
                if module_class and hasattr(module_class, 'get_instance_data'):
                    # Добавляем специфичные данные модуля
                    module_data.update(module_class.get_instance_data(module_instance))
                else:
                    # Если класса нет, оставляем только базовые данные
                    print(f"Класс для модуля {module_class_name} не найден в module_classes")

                modules_data.append(module_data)

    print("Данные модулей:", modules_data)
    return render_template('index.html', categories=categories, homePage=home_page, seo=seo,
                           site_settings=site_settings, modules=modules_data, auth=auth)


@main_bp.route('/category/<category_slug>')
def category(category_slug):
    if category_slug is None:
        return redirect('/')

    auth = current_user.is_authenticated
    category = getCategoryBySlug(category_slug)
    cat_products = getProductsByCategoryID(category.id)
    categories = getPcats()
    seo = getSEO('category', category.id)
    subCategories = getSybCategoryByID(category.id)
    site_settings = getSiteSettings()

    # Загружаем опции для всех товаров в списке
    product_options = {}
    all_options = {}  # Собираем все уникальные опции для фильтров
    all_attributes = {}  # Собираем все уникальные атрибуты для фильтров
    
    for product in cat_products:
        options = ProductOption.get_options_by_product_id(product.id)
        product_options[product.id] = options
        
        # Собираем уникальные опции для фильтров
        for option in options:
            option_name = option['name']
            if option_name not in all_options:
                all_options[option_name] = {
                    'id': option['id'],
                    'name': option_name,
                    'display_type': option['display_type'],
                    'values': {}
                }
            
            # Собираем уникальные значения опций
            for value in option['values']:
                value_id = value['id']
                if value_id not in all_options[option_name]['values']:
                    all_options[option_name]['values'][value_id] = {
                        'id': value_id,
                        'value': value['value'],
                        'count': 0
                    }
                all_options[option_name]['values'][value_id]['count'] += 1
    
    # Преобразуем в списки для удобства в шаблоне
    filter_options = []
    for option_name, option_data in all_options.items():
        option_values = list(option_data['values'].values())
        filter_options.append({
            'id': option_data['id'],
            'name': option_name,
            'display_type': option_data['display_type'],
            'option_values': option_values  # Переименовываем values в option_values
        })

    return render_template(
        'front/category.html',
        categories=categories,
        category=category,
        cat_products=cat_products,
        seo=seo,
        subCategories=subCategories,
        site_settings=site_settings,
        auth=auth,
        product_options=product_options,
        filter_options=filter_options  # Добавляем опции для фильтров
    )


@main_bp.route('/product/<product_slug>')
def product(product_slug):
    if product_slug is None:
        return redirect('/')

    auth = current_user.is_authenticated
    categories = getPcats()
    product = getProductBySlug(product_slug)
    seo = getSEO('product', product.id)
    site_settings = getSiteSettings()
    options = ProductOption.get_options_by_product_id(product.id)
    variations = ProductVariation.get_variations_by_product_id(product.id)

    # Получаем до 6 других товаров из той же категории
    related_products = Product.query.filter(
        Product.category_id == product.category_id,
        Product.id != product.id  # исключаем текущий товар
    ).order_by(Product.sort_order, Product.id).limit(6).all()

    # Получаем опции для этих товаров
    product_options = {}
    for related in related_products:
        product_options[related.id] = ProductOption.get_options_by_product_id(related.id)

    return render_template(
        'front/product2.html',
        product=product,
        categories=categories,
        seo=seo,
        site_settings=site_settings,
        auth=auth,
        options=options,
        variations=variations,
        cat_products=related_products,
        product_options=product_options
    )


@main_bp.route('/search', methods=['GET'])
def search_products():
    query = request.args.get('query', '')  # Получаем текст поиска из запроса
    if len(query) > 3:  # Ограничение: минимум 4 символа
        # Ищем товары, где название содержит query (регистронезависимо)
        products = Product.query.filter(Product.name.ilike(f'%{query}%')).limit(10).all()
        # Преобразуем в список словарей
        results = [{'name': p.name, 'slug': p.slug, 'image': p.main_image.filename, 'price': p.price} for p in products]
        print(results)
        return jsonify(results)  # Возвращаем JSON

    return jsonify([])


@main_bp.route('/category/<category_slug>/filter', methods=['POST'])
@csrf.exempt
def filter_category_products(category_slug):
    """Применение фильтров к товарам категории"""
    try:
        data = request.get_json()
        filters = data.get('filters', {})
        sort = data.get('sort', 'popular')
        
        print(f"=== FILTER REQUEST ===")
        print(f"Category: {category_slug}")
        print(f"Filters: {filters}")
        print(f"Sort: {sort}")
        
        # Получаем категорию
        category = Category.query.filter_by(slug=category_slug).first()
        if not category:
            return jsonify({'error': 'Category not found'}), 404
        
        # Получаем все подкатегории текущей категории
        all_category_ids = get_all_subcategories(category.id)
        
        # Базовый запрос для товаров категории и всех подкатегорий
        products_query = Product.query.filter(Product.category_id.in_(all_category_ids))
        
        # Применяем фильтры по опциям
        if filters:
            for option_id, value_ids in filters.items():
                if value_ids:  # Если есть выбранные значения
                    # Получаем товары, у которых есть эта опция с выбранными значениями
                    option_id = int(option_id)
                    value_ids = [int(vid) for vid in value_ids]
                    
                    # Подзапрос для получения product_id через прямую связь товаров с option_value
                    from ..models.productOptions import product_option_value_association
                    
                    subquery = db.session.query(product_option_value_association.c.product_id).filter(
                        product_option_value_association.c.option_value_id.in_(value_ids)
                    )
                    
                    products_query = products_query.filter(Product.id.in_(subquery))
        
        # Применяем сортировку
        if sort == 'new':
            products_query = products_query.order_by(Product.created_at.desc())
        elif sort == 'price_asc':
            products_query = products_query.order_by(Product.price.asc())
        elif sort == 'price_desc':
            products_query = products_query.order_by(Product.price.desc())
        else:  # popular (по умолчанию)
            products_query = products_query.order_by(Product.sort_order, Product.id)
        
        # Получаем отфильтрованные товары
        filtered_products = products_query.all()
        
        print(f"Found {len(filtered_products)} products after filtering")
        
        # Отладочная информация
        if len(filtered_products) == 0 and filters:
            print("=== DEBUG FILTERING ===")
            print(f"Total products in category (including subcategories): {Product.query.filter(Product.category_id.in_(all_category_ids)).count()}")
            print(f"Total variations in category (including subcategories): {ProductVariation.query.join(Product).filter(Product.category_id.in_(all_category_ids)).count()}")
            
            for option_id, value_ids in filters.items():
                print(f"Checking option {option_id} with values {value_ids}")
                
                # Проверяем существование опции
                option = ProductOption.query.get(option_id)
                if option:
                    print(f"Option '{option.name}' exists")
                    
                    # Проверяем существование значений
                    values = ProductOptionValue.query.filter(
                        ProductOptionValue.id.in_(value_ids),
                        ProductOptionValue.option_id == option_id
                    ).all()
                    print(f"Found {len(values)} option values: {[v.value for v in values]}")
                    
                    # Проверяем товары с конкретными значениями через product_option_value_association
                    from ..models.productOptions import product_option_value_association
                    
                    # Сначала проверим все связи в таблице
                    all_associations = db.session.query(product_option_value_association).all()
                    print(f"Total associations in table: {len(all_associations)}")
                    print(f"All associations: {[(a.product_id, a.option_value_id) for a in all_associations]}")
                    
                    # Проверим связи для конкретных option_value_id
                    associations_for_values = db.session.query(product_option_value_association).filter(
                        product_option_value_association.c.option_value_id.in_(value_ids)
                    ).all()
                    print(f"Associations for values {value_ids}: {[(a.product_id, a.option_value_id) for a in associations_for_values]}")
                    
                    # Получим все подкатегории текущей категории
                    all_category_ids = get_all_subcategories(category.id)
                    print(f"All category IDs (including subcategories): {all_category_ids}")
                    
                    # Проверим товары в категории и всех подкатегориях
                    category_products = Product.query.filter(Product.category_id.in_(all_category_ids)).all()
                    print(f"Category products (including subcategories): {[(p.id, p.name, p.category.name if p.category else 'No category') for p in category_products]}")
                    
                    products_with_values = db.session.query(Product).join(
                        product_option_value_association, Product.id == product_option_value_association.c.product_id
                    ).filter(
                        product_option_value_association.c.option_value_id.in_(value_ids),
                        Product.category_id.in_(all_category_ids)
                    ).all()
                    print(f"Found {len(products_with_values)} products with selected values in category")
                    
                    # Показываем какие товары найдены
                    if products_with_values:
                        print(f"Products found: {[p.name for p in products_with_values]}")
                    else:
                        print("No products found with these option values")
                else:
                    print(f"Option {option_id} not found")
        
        # Формируем HTML для товаров
        products_html = []
        for product in filtered_products:
            # Получаем опции для товара
            product_options = ProductOption.get_options_by_product_id(product.id)
            
            # Формируем HTML карточки товара
            product_html = f'''
            <div class="col-6 col-lg-3 mb-4 product-item">
                <span class="fav-btn" data-product-id="{product.id}">
                    <svg xmlns="http://www.w3.org/2000/svg" width="24" height="24" fill="currentColor"
                         class="bi bi-heart-fill" viewBox="0 0 16 16">
                        <path fill-rule="evenodd"
                              d="M8 1.314C12.438-3.248 23.534 4.735 8 15-7.534 4.736 3.562-3.248 8 1.314"/>
                    </svg>
                </span>
                <a href="/product/{product.slug}" data-product-id="{product.id}" class="product_item">
                    <div class="product-image">
                        <img src="/static/uploads/{product.main_image.filename}" alt="{product.name}"
                             class="img-fluid w-100">
                    </div>
                </a>
                <div class="row py-2">
                    <div class="col-6">
                        <a href="/product/{product.slug}" data-product-id="{product.id}" class="product_item">
                            <h6>{product.name}</h6>
                        </a>
                    </div>
                    <div class="col-6 d-flex justify-content-end">
                        <p class="fs-6">{product.price} р.</p>
                        <button class="cat-catalog-btn add-to-cart-btn" id="add-to-cart"
                                style="border: none; background: transparent">
                            <img src="/static/icons/add-cart.png">
                        </button>
                    </div>
                    <div class="mt-4 color-options">
                        {''.join([f'''
                        <div class="top-palletes d-flex">
                            {''.join([f'''
                            <div class="pallete-color pallete-color-{color['value'].lower()} {'active' if i == 0 else ''} cursor-pointer position-relative me-3 transition wh-26 rounded-circle"
                                 data-pallet="core"
                                 data-color-name="{color['value'].capitalize()}">
                            </div>
                            ''' for i, color in enumerate(option['values']) if option['display_type'] == 'color']) }
                        </div>
                        ''' for option in product_options if option['display_type'] == 'color']) }
                    </div>
                </div>
            </div>
            '''
            products_html.append(product_html)
        
        return jsonify({
            'success': True,
            'products_count': len(filtered_products),
            'products_html': ''.join(products_html)
        })
        
    except Exception as e:
        print(f"Error in filter_category_products: {e}")
        return jsonify({'error': str(e)}), 500


@main_bp.route('/custom-auth', methods=['GET', 'POST'])
def custom_auth(action=None):
    # Если пользователь уже авторизован, перенаправляем на главную
    if current_user.is_authenticated and isinstance(current_user, Customer):
        return redirect(url_for('main.index'))  # Замените 'main.index' на вашу главную страницу

    if request.method == 'POST':
        action = request.form.get('action')  # Определяем, вход или регистрация

        if action == 'login':
            email = request.form.get('loginEmail')
            password = request.form.get('loginPassword')

            # Проверка входных данных
            if not email or not password:
                flash('Email и пароль обязательны для входа.', 'danger')
                return render_template('auth.html')

            # Поиск клиента
            customer = Customer.query.filter_by(email=email).first()

            if customer and customer.check_password(password):
                login_user(customer)
                flash('Вход выполнен успешно!', 'success')
                return redirect(url_for('main.index'))
            else:
                flash('Неверный email или пароль.', 'danger')

        elif action == 'register':
            name = request.form.get('registerName')
            email = request.form.get('registerEmail')
            password = request.form.get('registerPassword')
            confirm_password = request.form.get('registerConfirmPassword')

            # Проверка входных данных
            if not all([name, email, password, confirm_password]):
                flash('Все поля обязательны для регистрации.', 'danger')
                return render_template('auth.html')

            if password != confirm_password:
                flash('Пароли не совпадают.', 'danger')
                return render_template('auth.html')

            try:
                # Создание клиента через addCustomer
                new_customer = addCustomer(name, email, password)
                login_user(new_customer)
                flash('Регистрация успешна! Добро пожаловать!', 'success')
                return redirect(url_for('main.index'))

            except ValueError as e:
                flash(str(e), 'danger')
            except Exception as e:
                db.session.rollback()
                flash('Ошибка при регистрации. Попробуйте снова.', 'danger')

    return redirect('/')


@main_bp.route('/logout')
@login_required
def logout():
    logout_user()
    flash('Вы вышли из системы.', 'success')
    return redirect('/')


@main_bp.route('/favorites', methods=['GET', 'POST'])
def favorite():
    if request.method == 'POST':
        product_id = request.form.get('product_id')
        if checkFavorite(current_user.id, product_id):
            deleteFavorite(current_user.id, product_id)
            return 'Товар удален из избранного'
        else:
            addFavorite(current_user.id, product_id)
            return 'Товар добавлен в избранные'

    else:
        seo = SEOSettings(
            page_type='favorite',
            page_id=0,
            meta_title='Избранное',
            meta_description='Закладки',
            meta_keywords='',
            slug='favorite'
        )
        categories = getPcats()
        customer_id = current_user.id
        favorites = getFavorites(customer_id)
        site_settings = getSiteSettings()
        return render_template('front/favorite.html', favorites=favorites, seo=seo, site_settings=site_settings,
                               auth=current_user.is_authenticated, categories=categories)


def is_safe_url(target):
    """Проверяет, что URL безопасен для редиректа."""
    ref_url = urlparse(request.host_url)
    test_url = urlparse(urljoin(request.host_url, target))
    return test_url.scheme in ('http', 'https') and ref_url.netloc == test_url.netloc


def get_session_id():
    """Возвращает или создаёт уникальный ID сессии."""
    if 'session_id' not in session:
        session['session_id'] = str(uuid.uuid4())
    return session['session_id']


def merge_session_cart_to_db():
    """Переносит корзину из сессии в базу данных для авторизованного пользователя."""
    if not current_user.is_authenticated or 'cart' not in session:
        return

    cart = session.get('cart', {})
    for product_id, quantity in cart.items():
        product = Product.query.get(product_id)
        if product and product.stock >= quantity:
            cart_item = CartItem.query.filter_by(customer_id=current_user.id, product_id=product_id).first()
            if cart_item:
                cart_item.quantity += quantity
            else:
                cart_item = CartItem(
                    customer_id=current_user.id,
                    product_id=product_id,
                    quantity=quantity
                )
                db.session.add(cart_item)
    db.session.commit()
    session.pop('cart', None)  # Очищаем корзину в сессии


@main_bp.route('/cart/add', methods=['POST'])
@csrf.exempt
def add_to_cart():
    product_id = request.form.get('product_id', type=int)
    quantity = request.form.get('quantity', type=int, default=1)
    selected_options_json = request.form.get('selected_options', '{}')
    
    print(f"Добавление в корзину: product_id={product_id}, quantity={quantity}, options={selected_options_json}")
    
    if not product_id or quantity < 1:
        flash('Неверный товар или количество.', 'danger')
        return redirect(request.referrer or url_for('main.index'))

    product = Product.query.get(product_id)
    if not product:
        flash('Товар не найден.', 'danger')
        return redirect(request.referrer or url_for('main.index'))

    # Парсим выбранные опции
    try:
        selected_options = json.loads(selected_options_json) if selected_options_json else {}
    except:
        selected_options = {}

    if current_user.is_authenticated and isinstance(current_user, Customer):
        # Для авторизованных пользователей
        # Ищем товар с такими же опциями
        cart_item = CartItem.query.filter_by(
            customer_id=current_user.id, 
            product_id=product_id,
            selected_options=selected_options_json
        ).first()
        
        if cart_item:
            cart_item.quantity += quantity
        else:
            cart_item = CartItem(
                customer_id=current_user.id, 
                product_id=product_id, 
                quantity=quantity
            )
            cart_item.set_selected_options(selected_options)
            db.session.add(cart_item)
        db.session.commit()
    else:
        # Для неавторизованных пользователей
        cart = session.get('cart', {})
        # Создаем уникальный ключ для товара с опциями
        cart_key = f"{product_id}_{hash(selected_options_json)}"
        cart[cart_key] = {
            'product_id': product_id,
            'quantity': cart.get(cart_key, {}).get('quantity', 0) + quantity,
            'selected_options': selected_options
        }
        session['cart'] = cart
        session.modified = True

    flash('Товар добавлен в корзину!', 'success')
    return 'Товар добавлен в корзину'


@main_bp.route('/cart/remove', methods=['POST'])
@csrf.exempt
def remove_from_cart():
    product_id = request.form.get('product_id', type=int)
    selected_options_json = request.form.get('selected_options', '{}')

    if not product_id:
        flash('Неверный товар.', 'danger')
        return redirect(request.referrer or url_for('main.index'))

    # Парсим выбранные опции
    try:
        selected_options = json.loads(selected_options_json) if selected_options_json else {}
    except:
        selected_options = {}

    if current_user.is_authenticated and isinstance(current_user, Customer):
        # Ищем товар с такими же опциями
        cart_item = CartItem.query.filter_by(
            customer_id=current_user.id, 
            product_id=product_id,
            selected_options=selected_options_json
        ).first()
        if cart_item:
            db.session.delete(cart_item)
            db.session.commit()
    else:
        cart = session.get('cart', {})
        # Создаем уникальный ключ для товара с опциями
        cart_key = f"{product_id}_{hash(selected_options_json)}"
        cart.pop(cart_key, None)
        session['cart'] = cart
        session.modified = True

    flash('Товар удален из корзины!', 'success')
    return redirect(request.referrer or url_for('main.index'))


@main_bp.route('/cart', methods=['GET'])
def view_cart():
    cart_items = []
    total_price = Decimal('0')

    if current_user.is_authenticated and isinstance(current_user, Customer):
        cart_items = CartItem.query.filter_by(customer_id=current_user.id).all()
        processed_cart_items = []
        
        for item in cart_items:
            # Получаем цену с учетом вариаций
            selected_options = item.get_selected_options()
            item_price = item.product.price
            
            if selected_options:
                # Находим подходящую вариацию
                variations = ProductVariation.get_variations_by_product_id(item.product_id)
                matching_variation = None
                for var_id, variation in variations.items():
                    if variation.get('option_value_ids') == list(selected_options.values()):
                        matching_variation = variation
                        break
                
                if matching_variation:
                    # Конвертируем float в Decimal
                    item_price = Decimal(str(matching_variation['price']))
                    total_price += item_price * item.quantity
                else:
                    total_price += item.product.price * item.quantity
            else:
                total_price += item.product.price * item.quantity
            
            # Создаем словарь для шаблона
            processed_cart_items.append({
                'product': item.product,
                'quantity': item.quantity,
                'selected_options': selected_options,
                'price': item_price
            })
        
        cart_items = processed_cart_items
    else:
        cart = session.get('cart', {})
        for cart_key, cart_data in cart.items():
            if isinstance(cart_data, dict):
                product = Product.query.get(cart_data['product_id'])
                quantity = cart_data['quantity']
                selected_options = cart_data.get('selected_options', {})
            else:
                # Старый формат для обратной совместимости
                product = Product.query.get(int(cart_key))
                quantity = cart_data
                selected_options = {}
            
            if product:
                # Получаем цену с учетом вариаций
                item_price = product.price
                if selected_options:
                    variations = ProductVariation.get_variations_by_product_id(product.id)
                    matching_variation = None
                    for var_id, variation in variations.items():
                        if variation.get('option_value_ids') == list(selected_options.values()):
                            matching_variation = variation
                            break
                    
                    if matching_variation:
                        # Конвертируем float в Decimal
                        item_price = Decimal(str(matching_variation['price']))
                        total_price += item_price * quantity
                    else:
                        total_price += product.price * quantity
                else:
                    total_price += product.price * quantity
                
                cart_items.append({
                    'product': product, 
                    'quantity': quantity,
                    'selected_options': selected_options,
                    'price': item_price
                })

    # Создаем карты для быстрого доступа к опциям и их значениям
    options_map = {}
    option_values_map = {}
    
    # Получаем все уникальные option_id и value_id из корзины
    all_option_ids = set()
    all_value_ids = set()
    
    for item in cart_items:
        selected_options = item.get('selected_options', {}) if isinstance(item, dict) else item.get_selected_options()
        all_option_ids.update(selected_options.keys())
        all_value_ids.update(selected_options.values())
    
    # Загружаем опции и их значения
    if all_option_ids:
        options = ProductOption.query.filter(ProductOption.id.in_(all_option_ids)).all()
        options_map = {option.id: option for option in options}
        
        if all_value_ids:
            option_values = ProductOptionValue.query.filter(ProductOptionValue.id.in_(all_value_ids)).all()
            option_values_map = {value.id: value for value in option_values}
    
    seo = SEOSettings(
        page_type='cart',
        page_id=0,
        meta_title='Корзина',
        meta_description='Корзина покупок',
        meta_keywords='',
        slug='cart'
    )
    categories = getPcats()
    site_settings = getSiteSettings()
    return render_template('front/cart.html', 
                           cart_items=cart_items, 
                           total_price=total_price, 
                           options_map=options_map,
                           option_values_map=option_values_map,
                           seo=seo,
                           site_settings=site_settings,
                           auth=current_user.is_authenticated, 
                           categories=categories)
