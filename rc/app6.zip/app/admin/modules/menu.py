"""
@file: app/admin/modules/menu.py
@description: Логика модуля меню для админ-панели
@dependencies: MenuModuleInstance, MenuItemExtended, Menu, MenuItem
@created: 2024-12-21
"""

from ...extensions import db
from ...models.modules.menu import MenuModuleInstance, MenuItemExtended
from ...models.menu import Menu, MenuItem
from ...models.page import Page
from ...models.category import Category
from ...models.post import Post
from ...models.post_category import PostCategory
from ...models.module import ModuleInstance


class MenuModule:
    """Класс для управления модулем меню в админ-панели"""

    @staticmethod
    def get_content_options():
        """
        Получает опции контента для селектов в форме
        Returns:
            dict: Словарь с опциями для селектов (JSON serializable)
        """
        categories = Category.query.all()
        post_categories = PostCategory.query.all()
        pages = Page.query.all()
        posts = Post.query.filter_by(is_published=True).all()
        
        return {
            'pages': [
                {'id': p.id, 'title': p.title, 'slug': p.slug}
                for p in pages
            ],
            'categories': [
                {'id': c.id, 'name': c.name, 'slug': c.slug}
                for c in categories
            ],
            'posts': [
                {'id': p.id, 'title': p.title, 'slug': p.slug}
                for p in posts
            ],
            'post_categories': [
                {'id': pc.id, 'title': pc.name, 'slug': pc.slug}
                for pc in post_categories
            ]
        }

    @staticmethod
    def save_instance(module_instance, form_data):
        """
        Сохраняет экземпляр модуля меню и его пункты с поддержкой вложенности и видео
        """
        try:
            print("=== НАЧАЛО СОХРАНЕНИЯ МЕНЮ ===")
            print("Form data keys:", list(form_data.keys()))
            print(f"Module instance ID: {module_instance.id}")

            # Получаем или создаем MenuModuleInstance
            menu_instance = MenuModuleInstance.query.filter_by(
                module_instance_id=module_instance.id
            ).first()

            if not menu_instance:
                print(f"MenuModuleInstance не найден для module_instance_id={module_instance.id}, создаем новый")
                menu = Menu.query.first()
                if not menu:
                    menu = Menu(name='Основное меню')
                    db.session.add(menu)
                    db.session.flush()
                menu_instance = MenuModuleInstance(
                    module_instance_id=module_instance.id,
                    menu_id=menu.id
                )
                db.session.add(menu_instance)
                db.session.flush()

            # Сохраняем основные поля
            menu_instance.title = form_data.get('menu_title', '')
            menu_instance.menu_style = form_data.get('menu_style', 'horizontal')
            menu_instance.max_depth = int(form_data.get('max_depth', 3))
            menu_instance.show_icons = bool(form_data.get('show_icons', False))
            menu_instance.enable_videos = bool(form_data.get('enable_videos', False))
            menu_instance.enable_audio = bool(form_data.get('enable_audio', False))
            db.session.flush()

            # Удаляем старые пункты меню
            MenuItemExtended.query.filter_by(menu_instance_id=menu_instance.id).delete()
            MenuItem.query.filter_by(menu_id=menu_instance.menu_id).delete()
            db.session.flush()

            # Сохраняем новые пункты меню (сначала MenuItem, потом MenuItemExtended)
            index = 0
            menu_items_map = {}  # index -> MenuItem
            while True:
                item_title = form_data.get(f'menu_item_{index}_title', None)
                if item_title is None:
                    break
                item_type = form_data.get(f'menu_item_{index}_type', 'custom')
                url = form_data.get(f'menu_item_{index}_custom_url', '') if item_type in ['custom', 'external'] else ''
                target_id = form_data.get(f'menu_item_{index}_target_id', None)
                if target_id and str(target_id).isdigit():
                    target_id = int(target_id)
                else:
                    target_id = None
                icon_id = form_data.get(f'menu_item_{index}_icon_id', None)
                if icon_id and str(icon_id).isdigit():
                    icon_id = int(icon_id)
                else:
                    icon_id = None
                video_id = form_data.get(f'menu_item_{index}_video_id', None)
                if video_id and str(video_id).isdigit():
                    video_id = int(video_id)
                else:
                    video_id = None
                description = form_data.get(f'menu_item_{index}_description', '')
                custom_class = form_data.get(f'menu_item_{index}_custom_class', '')
                position = int(form_data.get(f'menu_item_{index}_position', index))
                parent_index = form_data.get(f'menu_item_{index}_parent_id', None)
                parent_id = None
                if parent_index and str(parent_index).isdigit():
                    # parent_index - это индекс в форме, ищем id созданного MenuItem
                    parent_menu_item = menu_items_map.get(int(parent_index))
                    if parent_menu_item:
                        parent_id = parent_menu_item.id
                # Сохраняем MenuItem
                menu_item = MenuItem(
                    menu_id=menu_instance.menu_id,
                    title=item_title,
                    url=url,
                    parent_id=parent_id,
                    position=position
                )
                db.session.add(menu_item)
                db.session.flush()  # чтобы получить id
                menu_items_map[index] = menu_item
                # Сохраняем MenuItemExtended
                menu_item_ext = MenuItemExtended(
                    menu_instance_id=menu_instance.id,
                    menu_item_id=menu_item.id,
                    item_type=item_type,
                    target_id=target_id,
                    icon_id=icon_id,
                    video_id=video_id,
                    description=description,
                    custom_class=custom_class,
                    sort_order=position
                )
                db.session.add(menu_item_ext)
                print(f"Сохраняем пункт: {item_title}, type={item_type}, target_id={target_id}, url={url}, parent_id={parent_id}, video_id={video_id}")
                index += 1
            db.session.commit()
            print("=== СОХРАНЕНИЕ МЕНЮ ЗАВЕРШЕНО ===")
            from flask import redirect, url_for
            return redirect(url_for('admin.modules_list'))
        except Exception as e:
            db.session.rollback()
            print(f"Ошибка при сохранении меню: {e}")
            raise

    @staticmethod
    def load_instance_data(instance_id):
        """
        Загружает данные экземпляра модуля меню с подгрузкой имени файла видео для предпросмотра
        """
        print(f"=== ЗАГРУЗКА ДАННЫХ МЕНЮ instance_id: {instance_id} ===")
        from ...models.image import Image
        if not instance_id:
            print("instance_id не передан, возвращаем дефолтные значения")
            return {
                'moduleInstanceData': {
                    'title': 'Новое меню',
                    'menu_style': 'horizontal',
                    'max_depth': 3,
                    'show_icons': False,
                    'enable_videos': False
                },
                'items': [],
                'contentOptions': MenuModule.get_content_options()
            }
        menu_instance = MenuModuleInstance.query.filter_by(module_instance_id=instance_id).first()
        if not menu_instance:
            print("MenuModuleInstance не найден, возвращаем дефолтные значения")
            return {
                'moduleInstanceData': {
                    'title': 'Новое меню',
                    'menu_style': 'horizontal',
                    'max_depth': 3,
                    'show_icons': False,
                    'enable_videos': False
                },
                'items': [],
                'contentOptions': MenuModule.get_content_options()
            }
        print(f"Найден MenuModuleInstance: {menu_instance.id}, menu_id: {menu_instance.menu_id}")
        items = []
        if menu_instance.menu_id:
            base_items = MenuItem.query.filter_by(menu_id=menu_instance.menu_id).order_by(MenuItem.position).all()
            print(f"Найдено базовых пунктов меню: {len(base_items)}")
            for base_item in base_items:
                print(f"Обрабатываем базовый пункт: {base_item.id} - {base_item.title}")
                extended_item = MenuItemExtended.query.filter_by(
                    menu_instance_id=menu_instance.id,
                    menu_item_id=base_item.id
                ).first()
                video_filename = None
                if extended_item and extended_item.video_id:
                    video = Image.query.get(extended_item.video_id)
                    if video:
                        video_filename = video.filename
                item_data = {
                    'id': base_item.id,
                    'title': base_item.title,
                    'url': base_item.url,
                    'position': base_item.position,
                    'parent_id': base_item.parent_id,
                    'item_type': extended_item.item_type if extended_item else 'custom',
                    'target_id': extended_item.target_id if extended_item else None,
                    'icon_id': extended_item.icon_id if extended_item else None,
                    'video_id': extended_item.video_id if extended_item else None,
                    'video_filename': video_filename,
                    'description': extended_item.description if extended_item else '',
                    'custom_class': extended_item.custom_class if extended_item else '',
                    'show_in_catalog': extended_item.show_in_catalog if extended_item else False,
                    'open_in_new_tab': extended_item.open_in_new_tab if extended_item else False,
                    'is_featured': extended_item.is_featured if extended_item else False,
                    'sort_order': extended_item.sort_order if extended_item else base_item.position
                }
                items.append(item_data)
                print(f"Добавлен пункт в items: {item_data['title']}")
        module_instance_data = {
            'title': menu_instance.title or 'Меню сайта',
            'menu_style': getattr(menu_instance, 'menu_style', 'horizontal'),
            'max_depth': getattr(menu_instance, 'max_depth', 3),
            'show_icons': getattr(menu_instance, 'show_icons', True),
            'enable_videos': getattr(menu_instance, 'enable_videos', False),
        }
        print(f"moduleInstanceData: {module_instance_data}")
        result = {
            'moduleInstanceData': module_instance_data,
            'items': items,
            'contentOptions': MenuModule.get_content_options()
        }
        print(f"=== РЕЗУЛЬТАТ ЗАГРУЗКИ: {len(items)} пунктов ===")
        return result

    @staticmethod
    def build_menu_tree(menu_items, parent_id=None):
        """
        Строит иерархическое дерево меню
        
        Args:
            menu_items: Список пунктов меню
            parent_id: ID родительского элемента
            
        Returns:
            list: Иерархический список пунктов меню
        """
        tree = []
        for item in menu_items:
            if item['parent_id'] == parent_id:
                children = MenuModule.build_menu_tree(menu_items, item['id'])
                if children:
                    item['children'] = children
                tree.append(item)
        return tree

    @staticmethod
    def del_instance(module_id, instance_id):
        """
        Удаляет экземпляр модуля меню и связанные с ним данные.
        """
        from flask import flash, redirect, url_for
        from ...models.module import ModuleInstance
        
        # Проверяем, существует ли экземпляр модуля
        module_instance = ModuleInstance.query.get(instance_id)
        if not module_instance:
            flash("Ошибка: Экземпляр модуля не найден!", "danger")
            return redirect(url_for('admin.modules_list'))

        # Удаляем связанные записи из MenuModuleInstance
        menu_instance = MenuModuleInstance.query.filter_by(module_instance_id=instance_id).first()
        if menu_instance:
            # Удаляем все пункты меню, связанные с этим меню
            MenuItemExtended.query.filter_by(menu_id=menu_instance.menu_id).delete()
            MenuItem.query.filter_by(menu_id=menu_instance.menu_id).delete()
            
            # Удаляем само меню
            Menu.query.filter_by(id=menu_instance.menu_id).delete()
            
            # Удаляем экземпляр меню
            db.session.delete(menu_instance)

        # Удаляем сам экземпляр модуля
        db.session.delete(module_instance)

        # Фиксируем изменения в БД
        db.session.commit()

        flash("Экземпляр меню успешно удалён.", "success")
        return redirect(url_for('admin.modules_list')) 