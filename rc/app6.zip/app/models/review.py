from datetime import datetime
from ..extensions import db
from .base import BaseModel

class Review(BaseModel):
    __tablename__ = 'reviews'

    product_id = db.Column(db.Integer, db.ForeignKey('products.id'), nullable=False)
    customer_id = db.Column(db.Integer, db.ForeignKey('customers.id'), nullable=False)
    rating = db.Column(db.Integer, nullable=False)
    comment = db.Column(db.Text)
    created_at = db.Column(db.DateTime, default=datetime.utcnow)
    approved = db.Column(db.Boolean, default=False)

    product = db.relationship('Product', backref='reviews')
